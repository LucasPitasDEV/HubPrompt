# Prompt para Criação de Landing Page de Apresentação de Projeto

## Objetivo
Criar uma landing page moderna e profissional para apresentação de projetos corporativos, seguindo o estilo e estrutura da landing page do projeto "Melhoria do Checklist Comercial".

## Estrutura da Página

### 1. Seção Hero (Tela Cheia)
- Imagem de fundo de alta qualidade relacionada ao tema do projeto
- Título principal em destaque (H1)
- Subtítulo explicativo curto
- Botão de call-to-action para navegação interna
- Indicador de rolagem para baixo

### 2. Seção Desafio
- Título da seção
- Descrição do problema atual
- Comparação visual entre situação atual e futura em cards lado a lado
- Lista de pontos problemáticos em cada situação

### 3. Seção Solução
- Título da seção
- Descrição da solução proposta
- Imagem ilustrativa da solução (wireframe, mockup ou diagrama)
- Três cards de features principais com:
  - Ícone representativo
  - Título da feature
  - Descrição curta
  - Responsabilidades de cada equipe envolvida

### 4. Seção Benefícios
- Título da seção
- Descrição geral dos benefícios
- Grid de cards de benefícios (4-6 cards) com:
  - Ícone representativo
  - Título do benefício
  - Descrição detalhada
  - Destaque para stakeholders beneficiados

### 5. Seção Implementação
- Título da seção
- Descrição da abordagem de implementação
- Timeline visual com fases do projeto
- Para cada fase:
  - Título da fase
  - Duração estimada
  - Descrição das atividades
  - Entregáveis principais

### 6. Seção Conclusão
- Título da seção
- Resumo dos principais pontos
- Próximos passos recomendados
- Informações de contato

### 7. Rodapé
- Copyright e informações legais

## Estilo Visual

### Cores
- Cor primária: #4361ee (azul)
- Cor secundária: #3f37c9 (azul escuro)
- Cor de destaque: #4cc9f0 (azul claro)
- Cor de fundo claro: #f8f9fa
- Cor de texto escuro: #212529
- Cor de texto médio: #495057
- Cor de texto claro: #6c757d

### Tipografia
- Fonte principal: 'Poppins', sans-serif
- Tamanhos de fonte:
  - Título principal: 3rem
  - Títulos de seção: 2.5rem
  - Subtítulos: 1.5rem
  - Corpo de texto: 1rem
  - Texto pequeno: 0.875rem

### Elementos Visuais
- Sombras suaves para cards e elementos destacados
- Bordas arredondadas (border-radius: 1rem)
- Efeitos hover sutis em elementos interativos
- Ícones minimalistas em SVG
- Espaçamento generoso entre seções
- Transições suaves para interações

## Responsividade
- Layout fluido que se adapta a diferentes tamanhos de tela
- Breakpoints para dispositivos móveis, tablets e desktops
- Ajustes de tamanho de fonte e espaçamento para cada breakpoint
- Reorganização de grids para visualização em coluna única em dispositivos móveis

## Código HTML Base

```html
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Título do Seu Projeto</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* Variáveis CSS */
        :root {
            --primary: #4361ee;
            --primary-dark: #3f37c9;
            --primary-light: #4cc9f0;
            --secondary: #3a0ca3;
            --accent: #f72585;
            --light: #f8f9fa;
            --gray-100: #f8f9fa;
            --gray-200: #e9ecef;
            --gray-300: #dee2e6;
            --gray-400: #ced4da;
            --gray-500: #adb5bd;
            --gray-600: #6c757d;
            --gray-700: #495057;
            --gray-800: #343a40;
            --gray-900: #212529;
            --dark: #212529;
        }

        /* Estilos Gerais */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            line-height: 1.6;
            color: var(--gray-800);
            background-color: var(--light);
        }

        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 2rem;
        }

        section {
            padding: 5rem 0;
        }

        .section-title {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--gray-900);
            margin-bottom: 1rem;
            text-align: center;
        }

        .section-subtitle {
            font-size: 1.25rem;
            color: var(--gray-700);
            margin-bottom: 3rem;
            text-align: center;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
        }

        /* Estilos específicos para cada seção... */
        
        /* Adicione aqui os estilos para cada seção conforme o modelo */

    </style>
</head>
<body>
    <!-- Seção Hero -->
    <section class="hero">
        <img src="URL_DA_IMAGEM_DE_FUNDO" alt="Descrição da imagem" class="hero-bg">
        <div class="hero-content">
            <h1 class="hero-title">Título Principal do Projeto</h1>
            <p class="hero-subtitle">Subtítulo explicativo sobre o projeto</p>
            <a href="#desafio" class="hero-cta">Call to Action</a>
        </div>
        <div class="scroll-indicator">
            <span>Role para baixo</span>
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 14l-7 7m0 0l-7-7m7 7V3"></path>
            </svg>
        </div>
    </section>

    <!-- Seção Desafio -->
    <section id="desafio" class="challenge">
        <div class="container">
            <h2 class="section-title">O Desafio</h2>
            <p class="section-subtitle">Descrição do problema atual</p>
            
            <!-- Conteúdo da seção desafio -->
            
        </div>
    </section>

    <!-- Seção Solução -->
    <section id="solucao" class="solution">
        <div class="container">
            <h2 class="section-title">Nossa Solução</h2>
            <p class="section-subtitle">Descrição da solução proposta</p>
            
            <!-- Conteúdo da seção solução -->
            
        </div>
    </section>

    <!-- Seção Benefícios -->
    <section id="beneficios" class="benefits">
        <div class="container">
            <h2 class="section-title">Benefícios</h2>
            <p class="section-subtitle">Descrição dos benefícios</p>
            
            <!-- Conteúdo da seção benefícios -->
            
        </div>
    </section>

    <!-- Seção Implementação -->
    <section id="implementacao" class="implementation">
        <div class="container">
            <h2 class="section-title">Implementação</h2>
            <p class="section-subtitle">Descrição da abordagem de implementação</p>
            
            <!-- Conteúdo da seção implementação -->
            
        </div>
    </section>

    <!-- Seção Conclusão -->
    <section id="conclusao" class="conclusion">
        <div class="container">
            <h2 class="section-title">Próximos Passos</h2>
            <p class="section-subtitle">Resumo e próximas ações</p>
            
            <!-- Conteúdo da seção conclusão -->
            
        </div>
    </section>

    <!-- Rodapé -->
    <footer class="footer">
        <div class="container">
            <p>&copy; 2025 Sua Empresa. Todos os direitos reservados.</p>
        </div>
    </footer>
</body>
</html>
```

## Instruções de Uso

1. Substitua os textos de placeholder pelos conteúdos específicos do seu projeto
2. Substitua as URLs de imagens por imagens relevantes ao seu projeto
3. Ajuste as cores conforme a identidade visual da sua empresa
4. Complete os estilos CSS para cada seção seguindo o modelo da landing page de referência
5. Adicione ou remova seções conforme necessário para seu projeto específico
6. Teste a responsividade em diferentes dispositivos
7. Otimize as imagens para carregamento rápido

## Dicas para Conteúdo Eficaz

1. Mantenha os textos concisos e diretos
2. Use linguagem simples e evite jargões técnicos desnecessários
3. Destaque claramente os benefícios para cada stakeholder
4. Use imagens de alta qualidade que complementem o texto
5. Mantenha uma estrutura lógica que guie o leitor pela narrativa do projeto
6. Inclua dados quantitativos quando possível (economia de tempo, redução de custos, etc.)
7. Defina claramente as responsabilidades de cada equipe envolvida
8. Apresente um cronograma realista com marcos claros

## Exemplo de Prompt para Gerar Conteúdo Específico

Para gerar o conteúdo específico para sua landing page, use o seguinte formato:

```
Crie o conteúdo para uma landing page de apresentação do projeto CRM Food Service, seguindo a estrutura:

1. Título principal e subtítulo
2. Descrição do desafio atual (problemas enfrentados)
3. Descrição da solução proposta (3 principais características)
4. Benefícios para cada stakeholder (cliente, equipe comercial, equipe técnica)
5. Plano de implementação em 5 fases com duração e entregáveis
6. Conclusão e próximos passos

O projeto visa (identificar no blueprint) e será implementado para (identificar no blueprint) .
```

Este prompt ajudará a gerar um conteúdo estruturado que pode ser facilmente adaptado ao template da landing page.

@blueprint_stakeholders.md 