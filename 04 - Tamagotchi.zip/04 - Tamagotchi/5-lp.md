Prompt:
Crie uma landing page HTML moderna e criativa para o [NOME DO PROJETO] baseada no blueprint fornecido.

A landing page deve:
- Apresentar um design visual contemporâneo e inovador
- Utilizar uma paleta de cores que reflita naturalmente o tema principal do projeto
- Focar principalmente na transmissão clara de informações sobre o projeto
- Destacar de forma especial o público-alvo e como o projeto atende suas necessidades
- Incorporar elementos interativos criativos que enriqueçam a experiência
- Ser completamente responsiva e otimizada para todos os dispositivos

Estrutura sugerida:
1. Header criativo com navegação intuitiva
2. Seção principal impactante que comunique imediatamente o propósito do projeto
3. Seção dedicada ao público-alvo, destacando como o projeto resolve seus problemas específicos
4. Apresentação visual das funcionalidades principais do projeto
5. Seção informativa sobre benefícios e diferenciais
6. Footer com informações essenciais

Forneça o código HTML completo com CSS integrado. Priorize a clareza na apresentação das informações, mas utilize elementos visuais criativos para tornar a experiência memorável.

Blueprint:
[INSERIR BLUEPRINT AQUI]

Observações:
- Extraia do blueprint as informações mais relevantes sobre o público-alvo e adapte o design para este público
- Use elementos visuais e interativos que complementem a informação sem distrair
- Aplique técnicas modernas de design web para criar uma experiência visual impactante
- Mantenha o código limpo e eficiente
- Sinta-se livre para explorar sua criatividade nos elementos interativos