# Guia de Estudo: Model Context Protocol (MCP)

## Introdução
O Model Context Protocol (MCP) é um padrão aberto que padroniza a forma de conectar modelos de linguagem com diferentes fontes de dados e ferramentas, permitindo que aplicações forneçam contexto mais rico de modo consistente citeturn0search0. Anthropic, ao anunciar o MCP, ressalta que esse protocolo facilita integrações mais sustentáveis e reduz a necessidade de desenvolver conectores específicos para cada fonte de dados citeturn0search3. Segundo reportagem da Axios, o MCP está ganhando tração por simplificar a comunicação direta entre IA e sistemas empresariais, apesar de desafios de segurança e padronização citeturn0news48.

## 1. Visão Geral do Model Context Protocol
- **Definição:** o MCP funciona como um “USB-C” para aplicações de IA, oferecendo uma interface única e padronizada para acesso a dados e ferramentas por LLMs citeturn0search0.
- **Arquitetura Cliente–Servidor:** um cliente MCP (por exemplo, um IDE ou agente) envia requisições a um servidor MCP, que expõe funcionalidades específicas via APIs REST, `stdio` ou `sse` citeturn0search2.
- **Vantagens:** ao adotar o MCP, desenvolvedores podem reduzir o tempo de manutenção de integrações, pois novas fontes de dados podem ser adicionadas sem alterações no código do cliente citeturn0search3.
- **Adoção no mercado:** empresas como Replit, Codeium e Sourcegraph já implementaram servidores MCP para oferecer acesso contextual a repositórios de código e bancos de dados citeturn0news50.
- **Fluxo Geral:**
  1. Cliente envia requisição de contexto ao servidor MCP.
  2. Servidor consulta a fonte de dados (ex.: banco SQL) e retorna contexto estruturado.
  3. Cliente repassa contexto ao LLM, que gera respostas mais precisas citeturn0search10.

## 2. Configurando MCP na IDE Windsurf
1. **Acesse as configurações:** no Windsurf Editor, abra **Settings > Advanced Settings** ou utilize **Command Palette > Open Windsurf Settings Page** citeturn1search1.
2. **Localize a seção Cascade:** dentro de **Advanced Settings**, role até **Cascade** e você encontrará:
   - Botão para **Adicionar Novo Servidor MCP**.
   - Lista de servidores MCP já configurados.
   - Link para visualizar o arquivo bruto `mcp_config.json` diretamente na IDE citeturn1search1.
3. **Transporte MCP:** escolha entre `stdio` (streaming de entrada/saída) ou `/sse` (Server-Sent Events), conforme a necessidade do seu servidor citeturn1search1.

💡 **Dica:** consulte o guia oficial do [Mermaid](https://mermaid.js.org/) para ativar a pré-visualização de diagramas no Windsurf e facilitar a visualização do fluxo MCP.

## 3. Conectando o MCP ao SQL Server
Para expor suas bases SQL Server via MCP, siga estas orientações:

- **Servidor MCP em .NET (C#):** utilize o tutorial da Microsoft que demonstra como construir um servidor MCP em C#, permitindo que clientes solicitem dados SQL de forma padronizada citeturn0search18.
- **Servidor MCP em Node.js:** o repositório [JexinSam/mssql_mcp_server](https://github.com/JexinSam/mssql_mcp_server) no GitHub exemplifica como listar tabelas, executar consultas e aplicar controle de acesso em um servidor MCP para SQL Server citeturn0search13.
- **String de conexão segura:**
  \`\`\`
  Server=tcp:<host>,1433;
  Database=<db>;
  User ID=${MCP_USER};
  Password=${SQL_PASSWORD};
  Encrypt=true;
  TrustServerCertificate=false;
  \`\`\`
- ⚠️ **Alerta de segurança:** armazene credenciais em variáveis de ambiente, seguindo as práticas do Twelve-Factor App para manter segredos fora do código-fonte citeturn7search0.
- 🔐 **Key Vault no Azure:** em ambientes Azure, considere usar o Azure Key Vault para gerenciar segredos e restringir o acesso por identidades gerenciadas citeturn8search0.

## 4. Exemplos Práticos

### 4.1 Arquivo `mcp_config.json` mínimo
\`\`\`json
{
  "server": "mssql-mcp://localhost:4000",
  "auth": {
    "type": "sqlLogin",
    "user": "sa",
    "password": "${SQL_PASSWORD}"
  },
  "scopes": ["read.tables", "write.procedures"]
}
\`\`\`

### 4.2 Script T-SQL de teste de conexão
\`\`\`sql
-- Teste de conexão MCP SQL Server
SELECT TOP 1 name
FROM sys.tables;
\`\`\`

## 5. Diagramas Mermaid

### 5.1 Sequence Diagram
\`\`\`mermaid
sequenceDiagram
    participant IDE as Windsurf IDE
    participant Client as MCP Client (Cascade)
    participant Server as MCP Server
    participant DB as SQL Server

    IDE->>Client: Comando de consulta
    Client->>Server: Requisição MCP (tool.invoke)
    Server->>DB: Query SQL
    DB-->>Server: Resultado da query
    Server-->>Client: Contexto estruturado
    Client-->>IDE: Exibe resultado
\`\`\`

### 5.2 Flowchart (graph LR)
\`\`\`mermaid
graph LR
    A[Windsurf Settings] --> B{MCP Ativado?}
    B -- Sim --> C[Lista de Servidores MCP]
    B -- Não --> D[Ativar MCP em Config]
    C --> E[Armazenar config em mcp_config.json]
    E --> F[Ferramentas LLM (Cascade)]
    F --> G[SQL Server MCP]
\`\`\`

## 6. Cronograma de Estudos Sugerido
| Semana | Atividades                                      |
|--------|-------------------------------------------------|
| 1      | Estudo da especificação MCP e testes iniciais   |
| 2      | Configuração do MCP no Windsurf e exemplos      |
| 3      | Implementação de servidor MCP para SQL Server   |
| 4      | Testes avançados, segurança e documentação final|

## 7. Checklist de Revisão
- [ ] Conceitos do MCP compreendidos  
- [ ] MCP habilitado no Windsurf Editor  
- [ ] Servidor MCP configurado para SQL Server  
- [ ] Conexão segura e segredos gerenciados  
- [ ] Exemplos práticos testados com sucesso  
- [ ] Diagramas Mermaid adicionados e validados  

## 8. Recursos & Referências
- Model Context Protocol – Introdução: citeturn0search0  
- Anthropic – Apresentando o MCP: citeturn0search3  
- Microsoft Copilot Studio – Integração MCP: citeturn0search2  
- Axios – Notícia sobre o MCP: citeturn0news48  
- The Verge – Adoção de mercado do MCP: citeturn0news50  
- .NET Blog – Construindo servidor MCP em C#: citeturn0search18  
- GitHub – MSSQL MCP Server: citeturn0search13  
- The Twelve-Factor App – Variáveis de ambiente: citeturn7search0  
- Azure Key Vault – Documentação oficial: citeturn8search0  

## Conclusão
Neste guia, apresentamos os conceitos-chave do Model Context Protocol (MCP), ensinamos a habilitar e configurar o MCP no Windsurf Editor, e mostramos como expor seu SQL Server de forma segura e padronizada. Com exemplos práticos, diagramas Mermaid e um cronograma detalhado, você está pronto para acelerar suas integrações de IA, mantendo boas práticas de segurança e modularidade. Bom estudo!
