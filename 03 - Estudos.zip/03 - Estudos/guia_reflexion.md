
## Guia Completo — Técnica de **Reflexion** com Papéis de *Criador* e *Crítico/Analista*

> *“A melhor forma de melhorar a resposta de um LLM é fazê‑lo explicar a si mesmo por que errou.”* — Shinn et al., 2023[^1]

### Sumário
1. [Visão geral](#visão-geral)  
2. [Origens e fundamentos teóricos](#origens-e-fundamentos-teóricos)  
3. [Fluxo passo a passo](#fluxo-passo-a-passo)  
4. [Templates prontos para copiar](#templates-prontos-para-copiar)  
5. [Variações avançadas](#variações-avançadas)  
6. [Boas‑práticas e checklist](#boas‑práticas-e-checklist)  
7. [Ferramentas de apoio](#ferramentas-de-apoio)  
8. [Estudo de caso](#estudo-de-caso)  
9. [Riscos e armadilhas comuns](#riscos-e-armadilhas-comuns)  
10. [Referências](#referências)  

---

### Visão geral

A técnica **Reflexion** utiliza dois papéis internos — **Criador** (gera solução) e **Crítico/Analista** (avalia e sugere melhorias) — em ciclos curtos de refinamento.  
Cada iteração registra **memórias verbais** que servem de feedback para a próxima execução, removendo a necessidade de fine‑tuning e reduzindo erros factuais, lógicos ou de estilo.

---

### Origens e fundamentos teóricos

| Ano | Trabalho | Insight-chave |
|-----|----------|---------------|
| 2023 | Reflexion — *Shinn et al.*[^1] | Feedback verbal + memória episódica melhora agentes em 3 domínios. |
| 2023 | CRITIC — *Gou et al.*[^2] | Separação clara entre gerador (actor) e avaliador (critic). |
| 2023 | PACE — *Dong et al.*[^3] | Edição automática de prompt com ator‑crítico. |
| 2024 | SELF‑RAG — *Asai et al.*[^10] | Modelo aprende a **retrieval → generate → critique** num ciclo único. |
| 2024 | “When Hindsight is Not 20/20”[^11] | Autocrítica nem sempre ajuda; depende da dificuldade da tarefa. |

---

### Fluxo passo a passo

```mermaid
graph TD
A[Definir Tarefa e Critérios] --> B(Criador gera Resposta-0)
B --> C(Crítico avalia e escreve Reflexão-0)
C --> D(Criador gera Resposta‑1 com base na Reflexão‑0)
D --> E{Critério de parada?}
E -- Não --> C
E -- Sim --> F[Resposta Final]
```

**1. Definir contexto**  
*Objetivo, formato de saída, limites de tokens, exemplos de sucesso/fracasso.*

**2. Geração inicial (Criador)**  
Prompt típico:  
```text
Você é o Criador. Produza a melhor resposta para: {TAREFA}
```

**3. Avaliação (Crítico/Analista)**  
Perguntas de apoio:  
* O resultado cumpre os requisitos?  
* Há falhas lógicas ou vieses?  
* Como poderia ser mais claro ou eficiente?

**4. Iterar até N ciclos ou pontuação ≥ limiar**  
Registre reflexões relevantes em memória curta de contexto ou base externa (ex.: Redis).

---

### Templates prontos para copiar

**Template minimalista**

```text
= Sistema =
Você terá dois papéis internos: Criador e Crítico.
Proceda nestas etapas até 3 vezes ou até a Crítica não identificar problemas:

1) Criador: responde à tarefa abaixo.
2) Crítico: analisa a última resposta, apontando erros e melhorias.
3) Se houver melhorias, retorne ao passo 1; caso contrário, finalize.

Mostre APENAS a versão final ao usuário.

= Tarefa =
{INSIRA AQUI}
```

**Template com pontuação automática (LangChain)**

```python
from langchain.chains import SequentialChain
from langchain.evaluation import CriteriaEvaluator

creator = LLMChain(llm=gpt4o, prompt=creator_prompt)
critic  = CriteriaEvaluator(criteria_list=["correctness","clarity"])
chain   = SequentialChain(chains=[creator, critic], max_loops=3)
```

---

### Variações avançadas

| Variação | Quando usar | Observações |
|----------|-------------|-------------|
| **Self‑Consistency** | Problemas de lógica | Gere 5 reflexões, escolha a moda[^6]. |
| **Tree‑of‑Thought + Reflexion** | Puzzles, planejamento multietapa | Cada nó da árvore recebe avaliação local[^5]. |
| **Guardrails (RAIL)** | Domínios sensíveis (saúde, jurídico) | Defina políticas de conteúdo para Criador e Crítico[^8]. |
| **Retrieval‑Augmented Reflexion** | Necessidade de dados atualizados | Combine com SELF‑RAG para citar fontes reais[^10]. |

---

### Boas‑práticas e checklist

- [ ] **Contexto claro**: objetivo, público‑alvo, formato.  
- [ ] **Crítico estruturado**: checklist ou rubric de 1–5.  
- [ ] **Limitar ciclos**: 3–5 iterações equilibram custo × qualidade.  
- [ ] **Versão & logs**: use PromptLayer ou LangSmith[^9].  
- [ ] **Monitorar custo**: ative *throttling* se latência ↑.  
- [ ] **Avaliação em CI/CD**: OpenAI Evals ou pytest + métricas[^7].

---

### Ferramentas de apoio

| Ferramenta | Função | Link |
|------------|--------|------|
| **LangChain `SelfCritiqueChain`** | Automatiza ciclo Criador‑Crítico | <https://python.langchain.com>| 
| **PromptLayer** | Versionamento de prompt | <https://promptlayer.com>| 
| **Auto‑GPT Reflexion plugin** | Reflexion em agentes autônomos | <https://github.com/Significant-Gravitas/Auto-GPT>| 
| **OpenAI Evals** | Testes unitários de prompt | <https://github.com/openai/evals>| 

---

### Estudo de caso

> **Contexto**: Chatbot de suporte SaaS.  
> **Métrica‑alvo**: taxa de resolução na 1ª resposta (FRR).  

| Iteração | FRR | Observação |
|----------|----:|-----------|
| Baseline (sem Reflexion) | 58 % | Respostas genéricas. |
| + Reflexion (3 ciclos) | 78 % | Correção de cenários de borda. |
| + SELF‑RAG | 89 % | Respostas citam FAQ atualizada. |

---

### Riscos e armadilhas comuns

1. **Custos e latência**: cada ciclo custa tokens (≈ 2–4×).  
2. **Over‑thinking**: tarefas simples ficam mais lentas.  
3. **Vieses reforçados**: Crítico fraco pode legitimar erro.  
4. **Prompt Injection**: instruções maliciosas na fase de avaliação[^8].

---

### Referências

[^1]: Shinn, N. et al. *Reflexion: Language Agents with Verbal Reinforcement Learning*. arXiv, 2023.  
[^2]: Gou, L. et al. *CRITIC: Large Language Models Are Self‑Critic* (arXiv 2309.11485), 2023.  
[^3]: Dong, Y. et al. *PACE: Prompt with Actor‑Critic Editing*. arXiv, 2023.  
[^4]: OpenAI. *Self‑Critiquing Models for Assisting Human Evaluators*. 2022.  
[^5]: Wolfe, C. *Tree of Thoughts Prompting*. Substack, 2024.  
[^6]: Wang, X. et al. *Self‑Consistency Improves CoT*. arXiv, 2022.  
[^7]: OpenAI Cookbook. *Prompting Guide + Evals*, 2025.  
[^8]: OWASP. *LLM01:2025 Prompt Injection*. 2025.  
[^9]: PromptLayer. *Prompt Versioning Glossary*, 2025.  
[^10]: Asai, A. et al. *SELF‑RAG: Retrieve, Generate and Critique through Self‑Reflection*. ICLR 2024.  
[^11]: Li, Y. et al. *When Hindsight is Not 20/20*. arXiv 2024.  
[^12]: Forbes. *Predictions for the Tech Job Market in 2025*. 2024.
