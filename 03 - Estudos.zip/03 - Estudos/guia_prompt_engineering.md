# Prompt Engineering — Guia Detalhado

> **Este guia expande a masterclass “Engenharia de Prompt: O Guia Definitivo” (YouTube) com detalhes técnicos, exemplos práticos mostrados em aula e boas‑práticas extraídas de publicações de OpenAI, Anthropic, Google DeepMind, Microsoft e artigos acadêmicos.**  

## Visão geral rápida
Prompt engineering é o conjunto de métodos para descrever **_o que_** você quer de um LLM, **_como_** deve ser entregue e **_sob quais restrições_** – tudo isso codificado no texto do próprio prompt. Dominar essa competência reduz custos, aumenta a qualidade das respostas, viabiliza automações e abre vaga para perfis de _Prompt Engineer_.

---

## Fundamentos da Engenharia de Prompt

### Por que dominar?
* **Meta‑skill** – melhora toda tarefa mediada por IA (programação, marketing, atendimento).  
* **Ganho econômico** – empresas cortam *headcount* e liberam novos produtos só ajustando instruções.  
* **Vaga em alta** – portais como LinkedIn mostram salários > US$ 150 k/ano para *prompt specialists*.  

### Regras de ouro apresentadas no vídeo
1. **Comece simples, complique depois**.  
2. **Clareza > complexidade** – instruções curtas e específicas.  
3. **Prototipe em modelo topo de linha, otimize em um mais barato**.  
4. **Teste, meça, refatore** – trate prompt como código versionado.  

---

## Framework PROMPT (visto no vídeo)

| Letra | Significado | Exemplo |
|-------|-------------|---------|
| **P** – Persona | Define “quem” é o modelo | `Você é um Eng. de Software Sênior…` |
| **R** – Role | Macro‑tarefa | `Seu papel é revisar pull‑requests…` |
| **O** – Objective | Resultado | `Quero um relatório de bugs…` |
| **M** – Mode | Formato | `Retorne em Markdown com <json>` |
| **P** – Panorama | Contexto extra | `Projeto usa .NET 8, DDD…` |
| **T** – Transform | Passos de refinamento | `Pergunte se faltar algo, depois gere versão final` |

> **Dica:** salve cada bloco como chave JSON; fica fácil versionar em Git e injetar via API.

---

## Técnicas essenciais

### Zero‑Shot vs. Few‑Shot
* **Zero‑Shot** – confia só na instrução. Útil p/ tarefas genéricas.  
* **Few‑Shot** – adiciona 2–5 exemplos para reduzir ambiguidade.

### Chain‑of‑Thought (CoT)
Peça explicitamente:  
```text
Pense passo a passo antes da resposta final.
```  
Aumenta acurácia em matemática, lógica e programação.

### Self‑Consistency
Gera **n** cadeias de raciocínio independentes, escolhe por voto‑maioria.

### Skeleton‑of‑Thought (SoT)
Primeiro gere um *esqueleto* de respostas, depois aprofunde cada ponto em paralelo — reduz custo e latência.

### Directional Prompting
Combine **instrução + cot** + **rótulos de veracidade** para guiar o modelo em direção ao estilo ou política desejada.

### Reflexion
Peça ao agente para refletir sobre erros:  
```text
Após cada tentativa, descreva onde falhou, anote lições e tente novamente até acertar ou atingir 3 tentativas.
```

---

## Exemplos práticos mostrados no vídeo

### 1. Geração de Landing Page completa
```text
Você é um Web Designer Sênior.
Crie HTML + CSS para uma landing page cujo produto é “CRM Moovefy”.
Inclua seções: hero, benefícios (3 colunas), depoimento e CTA.  
O CSS deve ser *mobile first*; cores: #6C3FFF → #A166FF.
Retorne somente o código dentro de uma tag ```html.
```

### 2. Automação de e‑mails de suporte
*Entrada* (JSON):  
```json
{"cliente":"Acme SA","problema":"login expirado","prazo":"4h"}
```  
*Prompt*:  
```text
Gere um e‑mail de suporte compatível com o template abaixo.
Preencha variáveis dinâmicas a partir do JSON recebido.
```

### 3. Divisão de tarefas complexas  
Modelo A (Planner) decompõe a meta **“Escrever white‑paper IA”** em passos;  
Modelo B (Executor) recebe cada passo e produz o conteúdo;  
Modelo C (Revisor) aplica critérios de qualidade e consolida.

---

## Casos adicionais de outras fontes

| Técnica | Fonte | Mini‑exemplo |
|---------|-------|--------------|
| CoT Math | Wei et al., 2022 | “Quantas pernas 3 gatos e 2 cachorros têm? → Pense passo a passo…” |
| Self‑Consistency | Wang et al., 2022 | Gere 5 cadeias de raciocínio, selecione resposta modal. |
| SoT | Zhang et al., 2023 | Esboce título‑resumo‑tópicos antes de detalhar cada um. |
| JSON Output | Microsoft Azure Blog, 2024 | `Retorne estritamente este schema {title:string, bullets:string[]}` |
| Reflexion | Shinn et al., 2023 | Agente codifica solução, testa, reflete (`// REFLEXÃO:`) e itera. |

---

## Ferramentas & fluxo de trabalho

1. **VS Code + *Prompty*** – playground de prompt integrado.  
2. **Git** – versionar `*.prompt.json`, `test_cases.csv`, `expected_output.md`.  
3. **Planilhas / Eval frameworks** – rode 10–20 casos e marque “Pass/Fail”.  
4. **Dashboards (Grafana)** – acompanhe métricas como *exact‑match* e custo.  

### Pipeline sugerido

```mermaid
graph LR
A[Draft prompt] --> B[Test cases]
B --> C[Metrics & erros]
C --> D[Refinamento]
D --> B
D --> E[Prompt v1 tag no Git]
E --> F[Deploy API]
```

---

## Checklist rápido

- [ ] Persona e role definidos  
- [ ] Objetivo claro e mensurável  
- [ ] Formato de saída explicitado  
- [ ] Exemplo(s) incluído(s) se necessário  
- [ ] Instruções de pensamento passo a passo?  
- [ ] Limites de temperatura / tokens ajustados  
- [ ] Casos de teste e métricas registradas  
- [ ] Prompt versionado em repositório  

---

## Referências essenciais

1. [Bruno Picinini – “Engenharia de Prompt: O Guia Definitivo” (YouTube)](https://youtu.be/1VDcke66TRE?si=XXSMJSy-05wV-Hjn)  
2. [OpenAI – Best Practices for Prompt Engineering with the API](https://help.openai.com/en/articles/6654000-best-practices-for-prompt-engineering-with-the-openai-api)  
3. [Anthropic – Prompt Engineering Overview](https://docs.anthropic.com/en/docs/build-with-claude/prompt-engineering/overview)  
4. [Wei et al., “Chain-of-Thought Prompting Elicits Reasoning” (2022)](https://openreview.net/pdf?id=_VjQlMeSB_J)  
5. [Wang et al., “Self-Consistency Improves Chain-of-Thought Reasoning” (2022)](https://arxiv.org/abs/2203.11171)  
6. [Zhang et al., “Skeleton-of-Thought: Prompting LLMs for Efficient Parallel Generation” (2023)](https://arxiv.org/abs/2307.15337)  
7. [Shen et al., “Directional Stimulus Prompting” (2023)](https://www.promptingguide.ai/techniques/dsp)  
8. [Shinn et al., “Reflexion: Language Agents with Verbal Reinforcement Learning” (2023)](https://arxiv.org/abs/2303.11366)  
9. [Microsoft Learn – JSON mode with Azure OpenAI Service](https://learn.microsoft.com/en-us/azure/ai-services/openai/how-to/json-mode)  
10. [Microsoft Research – Synthetic Prompting](https://www.microsoft.com/en-us/research/publication/synthetic-prompting-generating-chain-of-thought-demonstrations-for-large-language-models/)  
11. [Shelf.io – Zero-Shot vs. Few-Shot Prompting](https://shelf.io/blog/zero-shot-and-few-shot-prompting/)  
12. [VS Code Extension – Prompty](https://marketplace.visualstudio.com/items?itemName=ms-toolsai.prompty)  


---
