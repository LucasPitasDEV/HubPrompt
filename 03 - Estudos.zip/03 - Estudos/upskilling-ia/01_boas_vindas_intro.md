# Guia do Instrutor: Bloco 1 - Boas-vindas e Introdução

**Duração:** 60 minutos

## Objetivos do Bloco:

*   Apresentar os objetivos do dia e do programa de upskilling em IA.
*   Introduzir o conceito de Modelos de Linguagem Grande (LLMs) e discutir seu potencial para desenvolvedores, com foco no **Windsurf**.
*   Promover uma discussão inicial baseada no material "IA para Devs: Cuidado com a armadilha!".
*   Apresentar os princípios básicos de Engenharia de Prompts, aplicados ao **Windsurf**.
*   Conscientizar sobre Ética, Limitações e Boas Práticas essenciais (Privacidade de Dados, Importância da Revisão Humana) ao usar o **Windsurf**.

## Atividades:

1.  **Boas-vindas e Apresentação dos Objetivos (10 min):**
    *   Recepcione o desenvolvedor.
    *   Apresente brevemente a agenda do dia.
    *   Destaque os objetivos principais: capacitar no uso do **Windsurf** para ganho de produtividade, com foco prático e consciente.

2.  **O que são LLMs e Seu Potencial com Windsurf (15 min):**
    *   Explique de forma acessível o que é um LLM e como o **Windsurf IDE** o integra para auxiliar desenvolvedores.
    *   Mostre exemplos práticos de como o **Windsurf** pode auxiliar desenvolvedores:
        *   Geração de código (boilerplate, funções pequenas)
        *   Explicação de trechos de código
        *   Auxílio em debugging
        *   Sugestões de refatoração
        *   Criação de documentação (docstrings, comentários)
        *   Geração de ideias para testes unitários
        *   Brainstorming de soluções técnicas

3.  **Discussão: "IA para Devs: Cuidado com a armadilha!" (15 min):**
    *   Pergunte se o desenvolvedor leu o material prévio (`resumo_IA_para_Devs.md`).
    *   Conduza uma breve discussão sobre os pontos principais:
        *   O risco da dependência e de copiar/colar sem entender.
        *   Importância de não tratar a IA como um oráculo infalível.
        *   Riscos técnicos (bugs sutis, vulnerabilidades, licenciamento).
        *   Boas práticas: IA como *pair programmer*, iterar em prompts, revisão humana, testes.

4.  **Princípios Básicos de Engenharia de Prompts (10 min):**
    *   Introduza a ideia de que a qualidade do prompt afeta diretamente a qualidade da resposta no **Windsurf**.
    *   Apresente o framework PROMPT (do `engenharia_prompt_2025.md`) de forma simplificada ou alguns princípios chave, contextualizando para o **Windsurf**:
        *   **Clareza:** Seja direto e específico ao instruir o **Windsurf**.
        *   **Contexto:** Forneça informações relevantes (linguagem, trechos de código, etc.) para o **Windsurf**.
        *   **Especificidade:** Detalhe o que você espera do **Windsurf** (formato, linguagem, etc.).
        *   **Persona (Opcional para início):** Instruir o **Windsurf** a agir como um especialista (se aplicável à sua funcionalidade).

5.  **Ética, Limitações e Boas Práticas Essenciais com Windsurf (10 min):**
    *   **Privacidade de Dados no Windsurf:** Discuta as políticas de dados e privacidade específicas do **Windsurf IDE**. Esclareça como os dados (incluindo código) são processados, armazenados e se há comunicação com serviços externos. **NUNCA** insira dados sensíveis da empresa, clientes, ou informações confidenciais no **Windsurf** sem entender plenamente estas políticas. (Se o Windsurf opera localmente ou em um ambiente privado controlado pela empresa, ajuste a ênfase, mas mantenha a importância da conscientização sobre o fluxo dos dados).
    *   **Revisão Humana Crítica:** O código gerado pelo **Windsurf** é uma sugestão e **PRECISA** ser revisado, entendido e testado.
    *   **Vieses e Alucinações:** Assim como outros LLMs, o **Windsurf** pode gerar informações incorretas ou enviesadas. Mantenha o ceticismo.
    *   **Plágio e Licenciamento:** Tenha cuidado com trechos de código gerados pelo **Windsurf** que podem ser protegidos por direitos autorais.

## Material de Apoio Principal para este Bloco:

*   `resumo_IA_para_Devs.md` (principalmente para a discussão)
*   Conceitos iniciais do `engenharia_prompt_2025.md` (Framework PROMPT)

## Dicas para o Instrutor:

*   Mantenha um tom conversacional e incentive a participação.
*   Use exemplos simples e diretos.
*   Relacione os conceitos com o dia a dia do desenvolvedor.
