# Guia do Instrutor: Bloco 2 - Mão na Massa 1

**Duração:** 50 minutos

## Objetivos do Bloco:

*   Familiarizar o desenvolvedor com o **Windsurf IDE** como a ferramenta LLM a ser utilizada.
*   Conduzir um exercício prático de interação com o **Windsurf** para explicar um código existente ou gerar um novo trecho de código/boilerplate.
*   Ensinar a importância da iteração nos prompts para refinar os resultados obtidos com o **Windsurf**.
*   Promover a discussão sobre a qualidade do código gerado pelo **Windsurf** e os ajustes necessários.

## Atividades:

1.  **Apresentação do Windsurf IDE (10 min):**
    *   Mostre a interface do **Windsurf IDE**, focando nas funcionalidades de IA.
    *   Explique como acessar os recursos de IA, onde digitar os prompts e como visualizar as respostas/sugestões do **Windsurf**.
    *   Destaque quaisquer configurações importantes ou dicas de uso específicas do **Windsurf** para interação com IA.

2.  **Exercício Prático Guiado 1: Explicação de Código OU Geração de Código com Windsurf (35 min):**
    *   **Escolha do Cenário (com o desenvolvedor):**
        *   **Opção A (Explicação):** Peça ao desenvolvedor para selecionar um pequeno trecho de código (idealmente do projeto atual ou um exemplo que ele ache um pouco complexo ou queira entender melhor) para que o **Windsurf** explique.
        *   **Opção B (Geração):** Peça ao desenvolvedor para descrever uma pequena funcionalidade, uma função utilitária ou um boilerplate que ele precise implementar frequentemente, para que o **Windsurf** gere.
    *   **Construção do Prompt Inicial para o Windsurf (juntos):**
        *   Baseado no cenário, ajude o desenvolvedor a formular um primeiro prompt para o **Windsurf**.
        *   Reforce os princípios: clareza, contexto (ex: linguagem de programação, o que o código faz/deveria fazer), especificidade.
        *   Exemplo (Explicação): `"Windsurf, explique este código Python e o que cada parte faz: [colar código aqui]"`
        *   Exemplo (Geração): `"Windsurf, gere uma função em JavaScript que recebe um array de números e retorna a soma de todos os números pares. Inclua comentários explicando a lógica."`
    *   **Análise da Primeira Resposta do Windsurf:**
        *   Analise a resposta/sugestão do **Windsurf** junto com o desenvolvedor.
        *   A resposta atendeu à solicitação? Foi clara? Completa?
    *   **Iteração no Prompt para o Windsurf (2-3 vezes):**
        *   Mostre como refinar o prompt para obter melhores resultados do **Windsurf**. Exemplos:
            *   `"Windsurf, refaça a explicação do código Python, mas foque nos possíveis efeitos colaterais da função X."`
            *   `"Windsurf, modifique a função JavaScript para que ela também trate arrays vazios retornando 0. Adicione um exemplo de uso."`
            *   Utilize o Framework PROMPT (do `engenharia_prompt_2025.md`) para guiar o refinamento das instruções para o **Windsurf**.
        *   A cada iteração, discuta as mudanças no prompt e o impacto na resposta do **Windsurf**.
    *   **Discussão sobre o Resultado Final do Windsurf:**
        *   O código gerado pelo **Windsurf** (se aplicável) está correto? Compila? É eficiente? Seguro?
        *   Quais ajustes manuais seriam necessários?
        *   A explicação fornecida pelo **Windsurf** (se aplicável) foi útil e precisa?

3.  **Debriefing do Exercício (5 min):**
    *   Pergunte ao desenvolvedor sobre a experiência com o **Windsurf**.
    *   O que ele achou da capacidade do **Windsurf** para essa tarefa?
    *   Quais foram as maiores dificuldades ou surpresas ao interagir com o **Windsurf**?

## Material de Apoio Principal para este Bloco:

*   `engenharia_prompt_2025.md` (especialmente o Framework PROMPT e exemplos de técnicas de prompting, aplicados ao **Windsurf**).
*   O **Windsurf IDE**.

## Dicas para o Instrutor:

*   Deixe o desenvolvedor interagir diretamente com as funcionalidades de IA do **Windsurf** o máximo possível, mesmo que com sua orientação.
*   Seja paciente e guie o processo de descoberta das capacidades do **Windsurf**.
*   Foque mais no *processo* de como chegar a um bom prompt para o **Windsurf** e analisar criticamente sua resposta do que em obter uma resposta perfeita de primeira.
*   Se o tempo estiver curto, foque em uma boa iteração de prompt com o **Windsurf** em vez de tentar vários cenários superficialmente.
