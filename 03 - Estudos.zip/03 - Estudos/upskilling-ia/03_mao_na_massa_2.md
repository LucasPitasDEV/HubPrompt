# Guia do Instrutor: Bloco 3 - Mão na Massa 2

**Duração:** 50 minutos

## Objetivos do Bloco:

*   Explorar o uso do **Windsurf IDE** para auxiliar no processo de debugging de código ou na sugestão de refatorações.
*   Praticar a formulação de prompts específicos para descrever problemas (bugs) ou objetivos de refatoração para o **Windsurf**.
*   Analisar criticamente as sugestões fornecidas pelo **Windsurf**, discutindo sua aplicabilidade e limitações.
*   Reforçar a importância da compreensão do código e da validação humana ao usar o **Windsurf**.

## Atividades:

1.  **Introdução ao Cenário (5 min):**
    *   Explique que o **Windsurf IDE** também pode ser útil para identificar causas de bugs ou sugerir melhorias em código existente.
    *   Destaque que o **Windsurf** não "entende" o bug no contexto completo do sistema, mas pode encontrar padrões ou sugerir caminhos com base na informação fornecida.

2.  **Exercício Prático Guiado 2: Auxílio no Debugging OU Sugestões de Refatoração com Windsurf (40 min):**
    *   **Escolha do Cenário (com o desenvolvedor):**
        *   **Opção A (Debugging):** Peça ao desenvolvedor para descrever um bug simples que ele enfrentou recentemente ou um bug hipotético fácil de reproduzir/explicar. É importante ter o trecho de código onde o bug ocorre e a mensagem de erro (se houver) para apresentar ao **Windsurf**.
        *   **Opção B (Refatoração):** Peça ao desenvolvedor para selecionar um pequeno trecho de código que ele acredita que poderia ser melhorado (mais legível, mais eficiente, seguindo melhores práticas, etc.) para que o **Windsurf** sugira melhorias.
    *   **Construção do Prompt Inicial para o Windsurf (juntos):**
        *   **Para Debugging:**
            *   Incluir o código relevante.
            *   Descrever o comportamento esperado vs. o comportamento observado (o erro).
            *   Incluir a mensagem de erro completa, se disponível.
            *   Exemplo: `"Windsurf, estou recebendo o erro 'TypeError: cannot read property 'name' of undefined' neste código JavaScript ao tentar acessar 'user.profile.name'. O objeto 'user' às vezes não tem 'profile'. Como posso corrigir isso e evitar o erro? Código: [colar código]"`
        *   **Para Refatoração:**
            *   Incluir o código.
            *   Especificar o objetivo da refatoração para o **Windsurf** (ex: melhorar legibilidade, reduzir complexidade, aplicar um design pattern específico, otimizar performance para um caso X).
            *   Exemplo: `"Windsurf, sugira como refatorar este método Java para torná-lo mais legível e seguir os princípios SOLID. O método faz X, Y, Z. Código: [colar código]"`
    *   **Análise da Resposta do Windsurf:**
        *   A sugestão do **Windsurf** para o bug faz sentido? Aborda a causa raiz provável?
        *   As sugestões de refatoração do **Windsurf** são válidas? Realmente melhoram o código no aspecto solicitado?
        *   O **Windsurf** explicou o porquê das suas sugestões?
    *   **Iteração no Prompt para o Windsurf (se necessário e houver tempo):**
        *   Pedir alternativas ao **Windsurf**: `"Windsurf, existe outra forma de corrigir este bug?"` ou `"Windsurf, quais são os prós e contras dessa sugestão de refatoração versus manter o código original?"`
        *   Pedir mais detalhes ao **Windsurf**: `"Windsurf, pode explicar melhor por que essa mudança na linha X corrige o problema?"`
    *   **Discussão Crítica:**
        *   O desenvolvedor implementaria a sugestão do **Windsurf**? Por quê? Quais seriam os próximos passos?
        *   Como o **Windsurf** ajudou (ou não) no processo de raciocínio sobre o problema?
        *   Reforçar que, especialmente para debugging, o **Windsurf** é uma ferramenta de apoio ao diagnóstico, não a solução final. O desenvolvedor precisa entender o problema.

3.  **Debriefing do Exercício (5 min):**
    *   O que o desenvolvedor aprendeu sobre usar o **Windsurf** para essas tarefas?
    *   Em que tipos de bugs ou refatorações ele acha que o **Windsurf** poderia ser mais útil?

## Material de Apoio Principal para este Bloco:

*   `engenharia_prompt_2025.md` (para técnicas de como descrever problemas e objetivos claramente ao **Windsurf**).
*   O **Windsurf IDE**.

## Dicas para o Instrutor:

*   Para debugging com **Windsurf**, problemas com escopo bem definido e mensagens de erro claras tendem a ter melhores resultados.
*   Para refatoração com **Windsurf**, quanto mais específico o objetivo, melhor a sugestão.
*   Encoraje o desenvolvedor a testar mentalmente (ou até mesmo em um ambiente de teste rápido) as sugestões do **Windsurf**.
*   Use este bloco para enfatizar que o **Windsurf** não substitui o conhecimento técnico e a capacidade analítica do desenvolvedor.
