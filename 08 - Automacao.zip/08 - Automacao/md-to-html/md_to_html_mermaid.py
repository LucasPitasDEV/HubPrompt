import os
import markdown
import re
from pathlib import Path

MERMAID_CDN = "https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js"

# Função para processar blocos mermaid e converter para <div class="mermaid">...
def preprocess_mermaid_blocks(md_content):
    # Regex para capturar blocos ```mermaid ... ```
    pattern = re.compile(r'```mermaid\s*([\s\S]*?)```', re.MULTILINE)
    return pattern.sub(lambda m: f'<div class="mermaid">\n{m.group(1).strip()}\n</div>', md_content)

# Função para converter markdown para HTML, preservando blocos mermaid e melhorando blocos de código
def convert_md_to_html(md_content):
    # Pré-processa blocos mermaid para <div class="mermaid">...</div>
    md_content = preprocess_mermaid_blocks(md_content)
    # Converte markdown normalmente
    html = markdown.markdown(
        md_content,
        extensions=["fenced_code", "tables", "codehilite"],
        output_format="html5"
    )
    # Substitui pós-processamento: <pre><code class="language-mermaid">...</code></pre> por <div class="mermaid">...</div>
    html = re.sub(r'<pre><code class="language-mermaid">([\s\S]*?)</code></pre>',
                  lambda m: f'<div class="mermaid">\n{m.group(1).strip()}\n</div>', html)
    # Scripts para Mermaid.js e highlight.js
    mermaid_script = f'''
    <script src="{MERMAID_CDN}"></script>
    <script>
      window.mermaid.initialize({{ startOnLoad: true }});
    </script>
    '''
    highlight_script = '''
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/github-dark.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js"></script>
    <script>hljs.highlightAll();</script>
    '''
    style = '''
    <style>
      @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');
      html, body {
        min-height: 100%;
        margin: 0;
        padding: 0;
        background: #f4f6fa;
        transition: background 0.3s;
      }
      body {
        font-family: 'Inter', 'Segoe UI', Arial, sans-serif;
        color: #222;
        margin: 0 auto;
        padding: 32px 8vw 32px 8vw;
        max-width: 900px;
        background: none;
      }
      h1, h2, h3, h4, h5 {
        font-weight: 700;
        color: #2b3957;
        margin-top: 1.4em;
        margin-bottom: 0.5em;
      }
      h1 { font-size: 2.3em; border-bottom: 2px solid #e5e9f2; padding-bottom: 0.2em; }
      h2 { font-size: 1.6em; border-bottom: 1px solid #e5e9f2; padding-bottom: 0.1em; }
      h3 { font-size: 1.25em; }
      p, ul, ol, table, pre { margin-top: 1em; margin-bottom: 1em; }
      ul, ol { padding-left: 2em; }
      table {
        border-collapse: separate;
        border-spacing: 0;
        width: 100%;
        background: #fff;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 1px 4px #0001;
      }
      th, td {
        border: 1px solid #e3e7ef;
        padding: 10px 16px;
      }
      th {
        background: #f0f3fa;
        font-weight: 600;
        color: #2b3957;
      }
      tr:nth-child(even) td { background: #f7fafd; }
      pre {
        background: #212936;
        color: #f3f3f3;
        padding: 18px;
        border-radius: 10px;
        overflow-x: auto;
        font-size: 1em;
        box-shadow: 0 1px 6px #0002;
      }
      pre code {
        background: none;
        color: inherit;
        padding: 0;
        border-radius: 0;
        font-size: inherit;
      }
      code {
        background: #f0f3fa;
        color: #2b3957;
        border-radius: 5px;
        padding: 2px 7px;
        font-size: 0.98em;
      }
      .mermaid {
        background: #fff;
        border-radius: 12px;
        margin: 26px 0;
        box-shadow: 0 2px 8px #0001;
        padding: 18px 8px 18px 8px;
        overflow-x: auto;
      }
      blockquote {
        border-left: 4px solid #6a8cff;
        background: #f4f8ff;
        color: #2b3957;
        margin: 1.5em 0;
        padding: 1em 1.5em;
        border-radius: 8px;
        font-style: italic;
      }
      /* Botão Dark Mode */
      #darkmode-toggle {
        position: fixed;
        top: 24px;
        right: 32px;
        z-index: 1000;
        background: #fff;
        color: #2b3957;
        border: 1px solid #e3e7ef;
        border-radius: 50px;
        padding: 10px 26px;
        font-size: 1em;
        font-weight: 600;
        box-shadow: 0 2px 8px #0001;
        cursor: pointer;
        transition: background 0.2s, color 0.2s;
      }
      #darkmode-toggle:hover {
        background: #2b3957;
        color: #fff;
      }
      /* Dark mode */
      html.darkmode, body.darkmode {
        background: #181c23 !important;
      }
      body.darkmode {
        color: #e4e8ef;
      }
      body.darkmode h1, body.darkmode h2, body.darkmode h3, body.darkmode h4, body.darkmode h5 {
        color: #c7d0e6;
        border-color: #222a3a;
      }
      body.darkmode table {
        background: #232a36;
        box-shadow: 0 1px 4px #0005;
      }
      body.darkmode th, body.darkmode td {
        border: 1px solid #2c3546;
      }
      body.darkmode th {
        background: #242d3a;
        color: #c7d0e6;
      }
      body.darkmode tr:nth-child(even) td { background: #1a1f27; }
      body.darkmode pre {
        background: #161a20;
        color: #e4e8ef;
        box-shadow: 0 1px 6px #0007;
      }
      body.darkmode code {
        background: #232a36;
        color: #e4e8ef;
      }
      body.darkmode .mermaid {
        background: #222a3a;
        box-shadow: 0 2px 8px #0005;
      }
      body.darkmode blockquote {
        background: #232a36;
        color: #c7d0e6;
        border-left: 4px solid #6a8cff;
      }
      #darkmode-toggle.dark {
        background: #232a36;
        color: #fff;
        border: 1px solid #444b5e;
      }
      #darkmode-toggle.dark:hover {
        background: #fff;
        color: #2b3957;
      }
      @media (max-width: 650px) {
        body { max-width: 98vw; padding: 6vw 2vw 6vw 2vw; }
        table, th, td { font-size: 0.95em; }
        h1 { font-size: 1.4em; }
        h2 { font-size: 1.1em; }
        #darkmode-toggle { right: 8vw; top: 12px; padding: 8px 14px; font-size: 0.97em; }
      }
    </style>
    '''
    darkmode_script = '''
    <script>
      const btn = document.createElement('button');
      btn.id = 'darkmode-toggle';
      btn.innerText = '🌙 Dark Mode';
      document.addEventListener('DOMContentLoaded', function() {
        document.body.appendChild(btn);
        btn.onclick = function() {
          const isDark = document.body.classList.toggle('darkmode');
          document.documentElement.classList.toggle('darkmode', isDark);
          btn.classList.toggle('dark', isDark);
          btn.innerText = isDark ? '☀️ Light Mode' : '🌙 Dark Mode';
        };
      });
    </script>
    '''
    html_full = f"""
    <html>
    <head>
      <meta charset='utf-8'>
      <title>Markdown para HTML com Mermaid</title>
      {style}
      {highlight_script}
    </head>
    <body>
      {html}
      {mermaid_script}
      {darkmode_script}
    </body>
    </html>
    """
    return html_full

def main():
    pasta = Path(__file__).parent
    arquivos_md = list(pasta.glob('*.md'))
    for arquivo_md in arquivos_md:
        with open(arquivo_md, encoding='utf-8') as f:
            conteudo_md = f.read()
        html = convert_md_to_html(conteudo_md)
        arquivo_html = arquivo_md.with_suffix('.html')
        with open(arquivo_html, 'w', encoding='utf-8') as f:
            f.write(html)
        print(f"Convertido: {arquivo_md.name} -> {arquivo_html.name}")

if __name__ == "__main__":
    main()
