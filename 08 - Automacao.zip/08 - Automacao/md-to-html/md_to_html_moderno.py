import os
import markdown
import re
from pathlib import Path
import bs4

MERMAID_CDN = "https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js"

# Função para processar blocos mermaid
def preprocess_mermaid_blocks(md_content):
    pattern = re.compile(r'```mermaid\s*([\s\S]*?)```', re.MULTILINE)
    return pattern.sub(lambda m: f'<div class="mermaid">\n{m.group(1).strip()}\n</div>', md_content)

# Função para converter markdown para HTML moderno
def convert_md_to_html_moderno(md_content):
    md_content = preprocess_mermaid_blocks(md_content)
    html = markdown.markdown(
        md_content,
        extensions=["fenced_code", "tables", "codehilite"],
        output_format="html5"
    )
    html = re.sub(r'<pre><code class="language-mermaid">([\s\S]*?)</code></pre>',
                  lambda m: f'<div class="mermaid">\n{m.group(1).strip()}\n</div>', html)
    mermaid_script = f'''
    <script src="{MERMAID_CDN}"></script>
    <script>
      window.mermaid.initialize {{
        startOnLoad: true,
        theme: 'base',
        themeVariables: {{
          primaryColor: '#fff',
          secondaryColor: '#fff',
          tertiaryColor: '#fff',
          primaryBorderColor: '#666',
          secondaryBorderColor: '#aaa',
          actorBorder: '#666',
          actorBkg: '#fff',
          nodeTextColor: '#23243a',
        }}
      }};
    </script>
    '''
    highlight_script = '''
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/github-dark.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js"></script>
    <script>hljs.highlightAll();</script>
    '''
    # Gera navegação dinâmica para títulos do markdown
    soup = bs4.BeautifulSoup(html, "html.parser")
    toc_links = []
    for tag in soup.find_all(['h1', 'h2', 'h3']):
        if not tag.get('id'):
            anchor = tag.text.strip().replace(' ', '-').replace('.', '').replace('/', '').lower()
            tag['id'] = anchor
        toc_links.append((tag.name, tag['id'], tag.text.strip()))
    toc_html = "\n".join([
        f'<a href="#{id_}" class="toc-link toc-{level}">{title}</a>'
        for level, id_, title in toc_links
    ])
    html = str(soup)
    style = '''
    <style>
      @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');
      body {
        font-family: 'Inter', 'Segoe UI', Arial, sans-serif;
        margin: 0;
        background: #fff;
        color: #23243a;
        display: flex;
        min-height: 100vh;
      }
      .sidebar {
        width: 200px;
        background: #fff;
        color: #6c5ce7;
        padding: 24px 16px 16px 16px;
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        min-height: 100vh;
        box-shadow: 1px 0 0 #ececec;
        border-right: 1px solid #ececec;
        transition: transform 0.3s cubic-bezier(.4,0,.2,1);
        position: fixed;
        left: 0; top: 0; bottom: 0;
        z-index: 1001;
        overflow-y: auto;
        max-height: 100vh;
      }
      .sidebar.hide { transform: translateX(-100%); }
      .sidebar.show { transform: translateX(0); }
      .sidebar h1 {
        font-size: 1.3em;
        margin-bottom: 18px;
        font-weight: 700;
        letter-spacing: 1px;
        color: #6c5ce7;
      }
      .sidebar nav {
        margin-top: 18px;
        width: 100%;
        display: flex;
        flex-direction: column;
        gap: 6px;
      }
      .sidebar nav .toc-link {
        color: #6c5ce7;
        text-decoration: none;
        font-weight: 500;
        font-size: 1em;
        opacity: 0.9;
        border-radius: 4px;
        padding: 4px 8px;
        transition: background 0.15s;
      }
      .sidebar nav .toc-link:hover {
        background: #f3f0fa;
        opacity: 1;
      }
      .sidebar nav .toc-h1 { margin-left: 0; }
      .sidebar nav .toc-h2 { margin-left: 12px; font-size: 0.97em; }
      .sidebar nav .toc-h3 { margin-left: 24px; font-size: 0.94em; }
      .content {
        flex: 1;
        padding: 40px 3vw 40px 3vw;
        max-width: 900px;
        margin: 0 auto;
        margin-left: 200px;
        transition: margin-left 0.3s cubic-bezier(.4,0,.2,1);
        background: #fff;
        box-shadow: 0 0 0 #fff0;
      }
      .api-header {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 24px;
      }
      .api-header h2 {
        font-size: 1.4em;
        font-weight: 700;
        color: #6c5ce7;
        margin: 0;
        letter-spacing: 0.5px;
      }
      .api-header .badge {
        background: #ece8fa;
        color: #6c5ce7;
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 0.98em;
        font-weight: 600;
      }
      h1, h2, h3, h4, h5 {
        font-weight: 700;
        color: #6c5ce7;
        margin-top: 1.3em;
        margin-bottom: 0.5em;
        border: none;
      }
      h1 { font-size: 1.7em; }
      h2 { font-size: 1.2em; }
      h3 { font-size: 1.05em; }
      p, ul, ol, table, pre { margin-top: 1em; margin-bottom: 1em; }
      ul, ol { padding-left: 1.5em; }
      table {
        border-collapse: collapse;
        width: 100%;
        background: #fff;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: none;
        margin-bottom: 1.5em;
      }
      th, td {
        border: 1px solid #ececec;
        padding: 8px 14px;
      }
      th {
        background: #f3f0fa;
        font-weight: 600;
        color: #6c5ce7;
      }
      tr:nth-child(even) td { background: #f8f7fa; }
      pre {
        background: #fff;
        color: #6c5ce7;
        padding: 14px;
        border-radius: 7px;
        overflow-x: auto;
        font-size: 0.98em;
        box-shadow: none;
      }
      pre code {
        background: none;
        color: inherit;
        padding: 0;
        border-radius: 0;
        font-size: inherit;
      }
      code {
        background: #f3f0fa;
        color: #6c5ce7;
        border-radius: 4px;
        padding: 2px 6px;
        font-size: 0.98em;
      }
      .mermaid {
        background: #fff;
        border-radius: 9px;
        margin: 18px 0;
        box-shadow: none;
        padding: 12px 4px 12px 4px;
        overflow-x: auto;
      }
      blockquote {
        border-left: 4px solid #6c5ce7;
        background: #f3f0fa;
        color: #6c5ce7;
        margin: 1.2em 0;
        padding: 0.9em 1.1em;
        border-radius: 6px;
        font-style: italic;
        box-shadow: none;
      }
      .card {
        background: #fff;
        border-radius: 8px;
        box-shadow: none;
        padding: 18px 14px;
        margin-bottom: 1.3em;
      }
      .sidebar-toggle {
        display: none;
        position: fixed;
        top: 18px;
        left: 12px;
        width: 32px;
        height: 32px;
        background: #6c5ce7;
        color: #fff;
        border: none;
        border-radius: 6px;
        z-index: 1100;
        font-size: 1.2em;
        cursor: pointer;
        box-shadow: none;
      }
      .sidebar-toggle:focus {outline: none;}
      @media (max-width: 900px) {
        .sidebar { transform: translateX(-100%); }
        .sidebar-toggle { display: block; }
        .content { margin-left: 0; }
      }
      @media (max-width: 600px) {
        .content { padding: 10px 1vw 10px 1vw; }
        h1 { font-size: 1.13em; }
        h2 { font-size: 1em; }
        .api-header h2 { font-size: 1.07em; }
      }
    </style>
    '''
    sidebar_toggle_btn = '''<button class="sidebar-toggle" id="sidebarToggle" title="Menu">☰</button>'''
    sidebar_script = '''
    <script>
      const toggleBtn = document.getElementById('sidebarToggle');
      const sidebar = document.querySelector('.sidebar');
      function toggleSidebar() {
        sidebar.classList.toggle('show');
        document.querySelector('.content').classList.toggle('show');
      }
      if (toggleBtn) {
        toggleBtn.onclick = toggleSidebar;
      }
      document.addEventListener('click', function(e) {
        if(window.innerWidth <= 900 && sidebar.classList.contains('show')) {
          if (!sidebar.contains(e.target) && e.target !== toggleBtn) {
            sidebar.classList.remove('show');
            document.querySelector('.content').classList.remove('show');
          }
        }
      });
    </script>
    '''
    html_full = f"""
    <html>
    <head>
      <meta charset='utf-8'>
      <title>Documentação Moderna</title>
      {style}
      {highlight_script}
    </head>
    <body>
      {sidebar_toggle_btn}
      <div class='sidebar'>
        <h1>Moovefy</h1>
        <nav>
          {toc_html}
        </nav>
      </div>
      <div class='content'>
        <div class='api-header'>
          <h2>Guia de Integração CRM-ERP</h2>
          <span class='badge'>v1.0</span>
        </div>
        {html}
        {mermaid_script}
      </div>
      {sidebar_script}
    </body>
    </html>
    """
    return html_full

def main():
    pasta = Path(__file__).parent
    arquivos_md = list(pasta.glob('*.md'))
    for arquivo_md in arquivos_md:
        with open(arquivo_md, encoding='utf-8') as f:
            conteudo_md = f.read()
        html = convert_md_to_html_moderno(conteudo_md)
        arquivo_html = arquivo_md.with_name(arquivo_md.stem + '_moderno.html')
        with open(arquivo_html, 'w', encoding='utf-8') as f:
            f.write(html)
        print(f"Convertido: {arquivo_md.name} -> {arquivo_html.name}")

if __name__ == "__main__":
    main()
