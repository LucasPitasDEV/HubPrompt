# Conversor PDF para Markdown

Este projeto é um conversor de PDF para Markdown (.md) via linha de comando, capaz de extrair:
- Texto
- Imagens
- Tabelas
- Links
- Metadados do PDF
- Texto de páginas digitalizadas (OCR)

As imagens extraídas são salvas em uma pasta separada e referenciadas no arquivo Markdown gerado.

## Pré-requisitos
- Python 3.8+
- Tesseract OCR instalado no sistema (necessário para OCR)

### Instalação do Tesseract
- **Windows:** Baixe em https://github.com/tesseract-ocr/tesseract
- **Linux:**
  ```sh
  sudo apt-get install tesseract-ocr
  ```

## Instalação das dependências Python
Na pasta do projeto, execute:
```powershell
$env:HTTP_PROXY=""
$env:HTTPS_PROXY=""
python -m pip install -r requirements.txt
```

## Como usar
Execute o script passando o caminho do PDF como argumento:
```sh
python extrai_pdf_para_md.py caminho/do/seu/arquivo.pdf
```

- Será gerado um arquivo `.md` com o mesmo nome do PDF.
- As imagens extraídas serão salvas em uma pasta `<nome_do_pdf>_imagens`.

## Observações
- O script tenta extrair texto pesquisável e, caso não encontre, aplica OCR automaticamente.
- Tabelas são convertidas para formato Markdown.
- Links e metadados são incluídos no arquivo Markdown.
- O projeto pode ser adaptado para outros formatos de saída conforme necessidade.

## Licença
Uso interno G2Solution / Moovefy. Adapte conforme sua política de licenciamento.
