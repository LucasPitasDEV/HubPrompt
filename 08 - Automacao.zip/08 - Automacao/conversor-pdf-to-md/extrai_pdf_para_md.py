import os
import sys
import fitz  # PyMuPDF
import pdfplumber
import pytesseract
from PIL import Image
from datetime import datetime

# Função para extrair metadados do PDF
def extrair_metadados(pdf_path):
    doc = fitz.open(pdf_path)
    meta = doc.metadata
    return meta

# Função para salvar imagens extraídas
def salvar_imagem(imagem, pasta, nome_base, idx):
    if not os.path.exists(pasta):
        os.makedirs(pasta)
    caminho = os.path.join(pasta, f"{nome_base}_img{idx}.png")
    imagem.save(caminho)
    return caminho

# Função para extrair imagens embutidas usando PyMuPDF
def extrair_imagens_embutidas(pdf_path, output_img_dir, nome_base):
    doc = fitz.open(pdf_path)
    imagens_extraidas = []
    for page_num in range(len(doc)):
        page = doc[page_num]
        for img_index, img in enumerate(page.get_images(full=True)):
            xref = img[0]
            base_image = doc.extract_image(xref)
            image_bytes = base_image["image"]
            img_ext = base_image["ext"]
            img_filename = os.path.join(output_img_dir, f"{nome_base}_pag{page_num+1}_img{img_index+1}.{img_ext}")
            if not os.path.exists(output_img_dir):
                os.makedirs(output_img_dir)
            with open(img_filename, "wb") as img_file:
                img_file.write(image_bytes)
            imagens_extraidas.append((page_num+1, img_filename))
    return imagens_extraidas

# Função para extrair texto, links, tabelas e OCR
def extrair_pdf(pdf_path, output_md, output_img_dir, sem_ocr=False):
    # Metadados
    meta = extrair_metadados(pdf_path)
    linhas_md = [f"# Extração de PDF: {os.path.basename(pdf_path)}\n"]
    linhas_md.append("## Metadados\n")
    for k, v in meta.items():
        linhas_md.append(f"- **{k}**: {v}")
    linhas_md.append("")

    nome_base = os.path.splitext(os.path.basename(pdf_path))[0]
    # Extrair imagens embutidas
    imagens_embutidas = extrair_imagens_embutidas(pdf_path, output_img_dir, nome_base)
    imagens_por_pagina = {}
    for pag, img_path in imagens_embutidas:
        imagens_por_pagina.setdefault(pag, []).append(img_path)

    # Texto, links, tabelas e OCR
    with pdfplumber.open(pdf_path) as pdf:
        for i, pagina in enumerate(pdf.pages):
            linhas_md.append(f"\n---\n\n## Página {i+1}\n")
            texto = pagina.extract_text()
            if texto:
                linhas_md.append(f"### Texto\n{texto}\n")
            # Links
            links = []
            if hasattr(pagina, 'hyperlinks'):
                links = pagina.hyperlinks or []
            if links:
                linhas_md.append("### Links\n")
                for link in links:
                    url = link.get('uri') or link.get('url')
                    if url:
                        linhas_md.append(f"- {url}")
            # Tabelas
            tabelas = pagina.extract_tables()
            if tabelas:
                linhas_md.append("### Tabelas\n")
                for tab in tabelas:
                    # Corrigir valores None para string vazia
                    header = [str(cell) if cell is not None else '' for cell in tab[0]]
                    linhas_md.append("\n| " + " | ".join(header) + " |")
                    linhas_md.append("|" + "---|" * len(tab[0]))
                    for row in tab[1:]:
                        row_fmt = [str(cell) if cell is not None else '' for cell in row]
                        linhas_md.append("| " + " | ".join(row_fmt) + " |")
            # Imagens embutidas
            if (i+1) in imagens_por_pagina:
                linhas_md.append("### Imagens Embutidas\n")
                for img_path in imagens_por_pagina[i+1]:
                    rel_path = os.path.relpath(img_path, os.path.dirname(output_md)).replace('\\', '/')
                    linhas_md.append(f"![Imagem página {i+1}]({rel_path})")
            # OCR em páginas sem texto
            if not texto and not sem_ocr:
                try:
                    im = pagina.to_image(resolution=300).original
                    import pytesseract
                    texto_ocr = pytesseract.image_to_string(im, lang='por')
                    if texto_ocr.strip():
                        linhas_md.append(f"### OCR\n{texto_ocr}\n")
                except Exception as e:
                    linhas_md.append(f"### OCR não realizado: {str(e)}\n")

    # Salvar arquivo Markdown
    with open(output_md, 'w', encoding='utf-8') as f:
        f.write("\n".join(linhas_md))
    print(f"Extração concluída! Markdown salvo em: {output_md}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Uso: python extrai_pdf_para_md.py <arquivo.pdf> [--sem-ocr]")
        sys.exit(1)
    pdf_path = sys.argv[1]
    if not os.path.exists(pdf_path):
        print(f"Arquivo não encontrado: {pdf_path}")
        sys.exit(1)
    nome_base = os.path.splitext(os.path.basename(pdf_path))[0]
    output_md = nome_base + ".md"
    output_img_dir = nome_base + "_imagens"
    sem_ocr = False
    if len(sys.argv) > 2 and sys.argv[2] == "--sem-ocr":
        sem_ocr = True
    extrair_pdf(pdf_path, output_md, output_img_dir, sem_ocr=sem_ocr)
