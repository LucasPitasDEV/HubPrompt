import customtkinter as ctk
import os
import pyperclip
from tkinter import filedialog, messagebox, ttk

class PromptGeneratorApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Gerador de Prompt para Análise de UX em Vue.js")
        self.geometry("800x700")

        # Variáveis de estado
        self.selected_template_path = ctk.StringVar()
        self.selected_vue_file_path = ctk.StringVar()
        self.project_directory_path = ctk.StringVar()
        self.vue_file_filter_query = ctk.StringVar()
        
        self.all_found_vue_files = [] # Lista completa de arquivos .vue encontrados no diretório
        self.current_file_list_to_display = [] # Lista de arquivos a serem exibidos (após filtro)
        self.displayed_files_count = 0
        self.files_per_page = 50 # Número de arquivos a carregar por vez

        # --- Barra de Status (DEVE SER CRIADA ANTES DE USAR update_status) ---
        self.status_label = ctk.CTkLabel(self, text="Inicializando...", anchor="w")
        self.status_label.grid(row=4, column=0, columnspan=2, padx=10, pady=5, sticky="ew")

        # Configuração do grid
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(3, weight=1) # Linha da lista de arquivos Vue

        # --- Seção de Templates ---
        template_frame = ctk.CTkFrame(self)
        template_frame.grid(row=0, column=0, columnspan=2, padx=10, pady=10, sticky="ew")
        template_frame.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(template_frame, text="Template de Análise:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.template_options = self.load_templates()
        self.template_menu = ctk.CTkOptionMenu(template_frame, variable=self.selected_template_path, values=self.template_options)
        self.template_menu.grid(row=0, column=1, padx=5, pady=5, sticky="ew")
        if self.template_options:
            self.selected_template_path.set(self.template_options[0])

        # --- Seção de Seleção de Arquivo Vue ---
        vue_selection_frame = ctk.CTkFrame(self)
        vue_selection_frame.grid(row=1, column=0, columnspan=2, padx=10, pady=5, sticky="ew")
        vue_selection_frame.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(vue_selection_frame, text="Diretório do Projeto Vue:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.project_dir_entry = ctk.CTkEntry(vue_selection_frame, textvariable=self.project_directory_path, width=300)
        self.project_dir_entry.grid(row=0, column=1, padx=5, pady=5, sticky="ew")
        ctk.CTkButton(vue_selection_frame, text="Procurar Diretório...", command=self.browse_project_directory).grid(row=0, column=2, padx=5, pady=5)

        ctk.CTkLabel(vue_selection_frame, text="Filtrar por nome:").grid(row=1, column=0, padx=5, pady=5, sticky="w")
        self.filter_entry = ctk.CTkEntry(vue_selection_frame, textvariable=self.vue_file_filter_query, width=200)
        self.filter_entry.grid(row=1, column=1, padx=5, pady=5, sticky="w")
        ctk.CTkButton(vue_selection_frame, text="Aplicar Filtro", command=self.apply_vue_file_filter).grid(row=1, column=2, padx=5, pady=5)

        # --- Resultados da Busca de Arquivos Vue ---
        results_frame = ctk.CTkFrame(self)
        results_frame.grid(row=2, column=0, columnspan=2, padx=10, pady=5, sticky="nsew")
        results_frame.grid_columnconfigure(0, weight=1)
        results_frame.grid_rowconfigure(0, weight=1)

        ctk.CTkLabel(results_frame, text="Arquivos .vue Encontrados:").pack(anchor="w", padx=5)
        
        self.vue_files_canvas = ctk.CTkCanvas(results_frame, borderwidth=0, background="#2B2B2B")
        self.vue_files_list_frame = ctk.CTkFrame(self.vue_files_canvas, fg_color="#2B2B2B")
        self.vue_files_scrollbar = ctk.CTkScrollbar(results_frame, command=self.vue_files_canvas.yview)
        self.vue_files_canvas.configure(yscrollcommand=self.vue_files_scrollbar.set)

        self.vue_files_scrollbar.pack(side="right", fill="y")
        self.vue_files_canvas.pack(side="left", fill="both", expand=True)
        self.vue_files_canvas.create_window((0,0), window=self.vue_files_list_frame, anchor="nw")

        self.vue_files_list_frame.bind("<Configure>", lambda e: self.vue_files_canvas.configure(scrollregion = self.vue_files_canvas.bbox("all")))
        self.vue_files_canvas.bind_all("<MouseWheel>", self._on_mousewheel) # Bind mouse wheel globally for the canvas

        self.load_more_button = ctk.CTkButton(results_frame, text="Carregar Mais Resultados", command=self.load_more_vue_files, state="disabled")
        self.load_more_button.pack(pady=5)

        # --- Seção de Geração e Output ---
        generation_frame = ctk.CTkFrame(self)
        generation_frame.grid(row=3, column=0, columnspan=2, padx=10, pady=10, sticky="ew")

        self.generate_button = ctk.CTkButton(generation_frame, text="Gerar Prompt", command=self.generate_prompt)
        self.generate_button.pack(pady=(5,0), fill="x", padx=5)

        self.prompt_output_label = ctk.CTkLabel(generation_frame, text="Prompt Gerado:")
        self.prompt_output_label.pack(anchor="w", padx=5, pady=(10,0))
        self.prompt_output_text = ctk.CTkTextbox(generation_frame, height=150, wrap="word")
        self.prompt_output_text.pack(fill="both", expand=True, padx=5, pady=5)

        # Sub-frame para botões de Copiar e Limpar ficarem lado a lado
        action_buttons_frame = ctk.CTkFrame(generation_frame)
        action_buttons_frame.pack(fill="x", pady=(0,5), padx=0) # padx=0 aqui, pois os botões internos terão padx
        action_buttons_frame.grid_columnconfigure(0, weight=1) # Coluna para o botão Copiar
        action_buttons_frame.grid_columnconfigure(1, weight=1) # Coluna para o botão Limpar

        self.copy_button = ctk.CTkButton(action_buttons_frame, text="Copiar para Área de Transferência", command=self.copy_to_clipboard)
        self.copy_button.grid(row=0, column=0, padx=(5,2), pady=5, sticky="ew")

        self.clear_button = ctk.CTkButton(action_buttons_frame, text="Limpar Prompt", command=self.clear_prompt_output)
        self.clear_button.grid(row=0, column=1, padx=(2,5), pady=5, sticky="ew")

    def _on_mousewheel(self, event):
        # Check if the mouse is over the vue_files_canvas or its children
        widget_under_mouse = self.winfo_containing(event.x_root, event.y_root)
        if widget_under_mouse == self.vue_files_canvas or widget_under_mouse.master == self.vue_files_canvas or widget_under_mouse.master == self.vue_files_list_frame:
            # Scroll by units, not pages. Negative for up, positive for down.
            scroll_val = -1 * (event.delta // 120) # Windows specific, adjust for other OS if needed
            self.vue_files_canvas.yview_scroll(scroll_val, "units")

    def load_templates(self):
        template_dir = os.path.join(os.path.dirname(__file__), "templates")
        if not os.path.exists(template_dir):
            os.makedirs(template_dir)
            self.update_status("Pasta 'templates' criada. Adicione arquivos .md de template.")
            return []
        try:
            templates = [f for f in os.listdir(template_dir) if f.endswith(".md")] 
            if not templates:
                self.update_status("Nenhum template (.md) encontrado na pasta 'templates'.")
                return []
            return templates
        except Exception as e:
            messagebox.showerror("Erro ao Carregar Templates", f"Não foi possível carregar templates: {e}")
            return []

    def browse_project_directory(self):
        dir_path = filedialog.askdirectory(title="Selecione o Diretório do Projeto Vue")
        if dir_path:
            self.project_directory_path.set(dir_path)
            self.update_status(f"Diretório do projeto selecionado: {dir_path}")
            self.vue_file_filter_query.set("") # Limpa o filtro anterior
            self.search_and_display_vue_files()
        else:
            self.update_status("Seleção de diretório cancelada.")

    def search_and_display_vue_files(self, filter_query=""):
        search_root = self.project_directory_path.get()
        if not search_root or not os.path.isdir(search_root):
            self.update_status("Por favor, selecione um diretório de projeto válido primeiro.")
            # messagebox.showwarning("Diretório Inválido", "Por favor, selecione um diretório de projeto válido primeiro.")
            return

        self.all_found_vue_files = self.find_vue_files(search_root, filter_query)
        self.displayed_files_count = 0
        self.clear_vue_file_list()
        
        if not self.all_found_vue_files:
            self.update_status(f"Nenhum arquivo .vue encontrado em '{search_root}'" + (f" com o filtro '{filter_query}'" if filter_query else "") + ".")
            self.load_more_button.configure(state="disabled")
            return
        
        self.update_status(f"{len(self.all_found_vue_files)} arquivo(s) .vue encontrado(s). Exibindo os primeiros.")
        self.load_more_vue_files()

    def find_vue_files(self, search_root_dir, file_name_query=""):
        matches = []
        query = file_name_query.lower().strip()
        for root, _, files in os.walk(search_root_dir):
            for file in files:
                if file.lower().endswith(".vue"):
                    if not query or query in file.lower():
                        matches.append(os.path.join(root, file))
        return sorted(matches) # Retorna ordenado para consistência

    def apply_vue_file_filter(self):
        query = self.vue_file_filter_query.get()
        self.search_and_display_vue_files(filter_query=query)

    def clear_vue_file_list(self):
        for widget in self.vue_files_list_frame.winfo_children():
            widget.destroy()
        self.selected_vue_file_path.set("")

    def load_more_vue_files(self):
        start_index = self.displayed_files_count
        end_index = self.displayed_files_count + self.files_per_page
        files_to_load = self.all_found_vue_files[start_index:end_index]

        if not files_to_load:
            self.load_more_button.configure(state="disabled")
            if self.displayed_files_count > 0:
                 self.update_status(f"Todos os {self.displayed_files_count} arquivos .vue foram carregados.")
            return

        for file_path in files_to_load:
            short_path = os.path.relpath(file_path, self.project_directory_path.get())
            rb = ctk.CTkRadioButton(self.vue_files_list_frame, text=short_path, variable=self.selected_vue_file_path, value=file_path)
            rb.pack(anchor="w", padx=5, pady=2)
        
        self.displayed_files_count += len(files_to_load)

        if self.displayed_files_count < len(self.all_found_vue_files):
            self.load_more_button.configure(state="normal")
            self.update_status(f"Exibindo {self.displayed_files_count} de {len(self.all_found_vue_files)} arquivos .vue.")
        else:
            self.load_more_button.configure(state="disabled")
            self.update_status(f"Todos os {len(self.all_found_vue_files)} arquivos .vue foram carregados.")
        
        # Atualiza a região de rolagem do canvas
        self.vue_files_list_frame.update_idletasks()
        self.vue_files_canvas.configure(scrollregion=self.vue_files_canvas.bbox("all"))

    def read_file_content(self, file_path):
        if not file_path or not os.path.exists(file_path):
            self.update_status(f"Erro: Arquivo não encontrado em '{file_path}'.")
            # messagebox.showerror("Erro de Arquivo", f"Arquivo não encontrado: {file_path}")
            return None
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return f.read()
        except Exception as e:
            self.update_status(f"Erro ao ler o arquivo '{os.path.basename(file_path)}': {e}")
            # messagebox.showerror("Erro de Leitura", f"Não foi possível ler o arquivo {file_path}: {e}")
            return None

    def generate_prompt(self):
        template_file_name = self.selected_template_path.get()
        vue_file_full_path = self.selected_vue_file_path.get()

        if not template_file_name:
            self.update_status("Por favor, selecione um template.")
            messagebox.showwarning("Seleção Necessária", "Por favor, selecione um template.")
            return
        
        template_path = os.path.join(os.path.dirname(__file__), "templates", template_file_name)

        if not vue_file_full_path:
            self.update_status("Por favor, selecione um arquivo .vue da lista.")
            messagebox.showwarning("Seleção Necessária", "Por favor, selecione um arquivo .vue da lista.")
            return

        template_content = self.read_file_content(template_path)
        vue_content = self.read_file_content(vue_file_full_path)

        if template_content is None or vue_content is None:
            # As mensagens de erro já foram dadas por read_file_content via update_status
            return

        try:
            vue_file_basename = os.path.basename(vue_file_full_path)
            prompt = template_content.replace("{{AQUI SERÁ INSERIDO O CONTEÚDO COMPLETO DO ARQUIVO .VUE}}", vue_content)
            prompt = prompt.replace("{{NOME_DO_ARQUIVO_VUE}}", vue_file_basename)
            
            self.prompt_output_text.delete("1.0", "end")
            self.prompt_output_text.insert("1.0", prompt)
            self.update_status(f"Prompt gerado com sucesso usando template '{template_file_name}' e arquivo '{vue_file_basename}'.")
        except Exception as e:
            self.update_status(f"Erro ao gerar o prompt: {e}")
            messagebox.showerror("Erro de Geração", f"Ocorreu um erro ao gerar o prompt: {e}")

    def copy_to_clipboard(self):
        prompt_text = self.prompt_output_text.get("1.0", "end-1c")
        if not prompt_text:
            self.update_status("Nada para copiar. Gere um prompt primeiro.")
            # messagebox.showwarning("Nada para Copiar", "O campo de prompt está vazio.")
            return
        try:
            pyperclip.copy(prompt_text)
            self.update_status("Prompt copiado para a área de transferência!")
        except pyperclip.PyperclipException as e:
            self.update_status(f"Erro ao copiar: {e}. Verifique se 'xclip' ou 'xsel' está instalado no Linux.")
            messagebox.showerror("Erro ao Copiar", f"Não foi possível copiar para a área de transferência: {e}\n\nNo Linux, você pode precisar instalar 'xclip' ou 'xsel':\nsudo apt-get install xclip\nOU\nsudo apt-get install xsel")
        except Exception as e:
            self.update_status(f"Erro inesperado ao copiar: {e}")
            messagebox.showerror("Erro ao Copiar", f"Ocorreu um erro inesperado: {e}")

    def clear_prompt_output(self):
        self.prompt_output_text.delete("1.0", "end")
        self.update_status("Campo de prompt limpo.")

    def update_status(self, message):
        self.status_label.configure(text=message)
        self.update_idletasks() # Força a atualização da UI para que a mensagem apareça imediatamente

if __name__ == "__main__":
    app = PromptGeneratorApp()
    app.mainloop()
