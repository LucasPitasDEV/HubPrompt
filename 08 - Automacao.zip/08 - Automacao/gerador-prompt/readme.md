# Gerador de Prompt para Análise de UX em Vue.js

Este script Python com interface gráfica (GUI) auxilia na geração de prompts personalizados para análise de experiência do usuário (UX) em componentes de interface de usuário (UI) desenvolvidos com Vue.js. Ele permite selecionar templates de análise e arquivos `.vue` específicos para gerar um prompt combinado, que pode ser usado como entrada para modelos de linguagem ou outras ferramentas de análise.

## Funcionalidades Principais

- **Interface Gráfica Amigável:** Construído com `customtkinter` para uma experiência de usuário moderna e intuitiva.
- **Seleção de Templates:** Permite carregar templates de prompt (arquivos `.md`) a partir de uma pasta `templates` local.
- **Seleção de Arquivos Vue.js:**
    - Seleção de um diretório de projeto Vue.
    - Listagem automática de todos os arquivos `.vue` encontrados no diretório e suas subpastas.
    - Paginação dos resultados para melhor performance com muitos arquivos ("Carregar Mais Resultados").
    - Filtragem da lista de arquivos `.vue` por nome.
- **Geração de Prompt:** Combina o template selecionado com o conteúdo do arquivo `.vue` escolhido, substituindo placeholders específicos:
    - `{{AQUI SERÁ INSERIDO O CONTEÚDO COMPLETO DO ARQUIVO .VUE}}`: Pelo conteúdo do arquivo `.vue`.
    - `{{NOME_DO_ARQUIVO_VUE}}`: Pelo nome do arquivo `.vue`.
- **Visualização e Cópia:**
    - Exibe o prompt gerado em uma caixa de texto.
    - Botão para copiar o prompt gerado para a área de transferência.
    - Botão para limpar o campo do prompt gerado.
- **Barra de Status:** Fornece feedback sobre as operações realizadas.

## Estrutura de Pastas Esperada

```
gerador-prompt/
├── gerador_prompt_vue.py  # O script principal da aplicação
├── templates/               # Pasta para armazenar os templates de prompt
│   └── exemplo_template.md  # Exemplo de arquivo de template
└── README.md                # Este arquivo
```

## Configuração e Instalação

### Pré-requisitos

- Python 3.x
- `pip` (gerenciador de pacotes Python)

### Dependências

O script utiliza as seguintes bibliotecas Python:

- `customtkinter`: Para a interface gráfica.
- `pyperclip`: Para a funcionalidade de copiar para a área de transferência.

### Passos para Instalação

1.  **Clone ou baixe o projeto** para o seu computador.
2.  **Navegue até o diretório do projeto** pelo terminal:
    ```bash
    cd caminho/para/gerador-prompt
    ```
3.  **Crie um ambiente virtual (recomendado):**
    ```bash
    python -m venv venv
    ```
    Ative o ambiente virtual:
    - Windows:
        ```bash
        .\venv\Scripts\activate
        ```
    - macOS/Linux:
        ```bash
        source venv/bin/activate
        ```
4.  **Instale as dependências:**
    ```bash
    pip install customtkinter pyperclip
    ```

## Como Usar

1.  **Execute o script:**
    ```bash
    python gerador_prompt_vue.py
    ```
2.  **Crie seus Templates:**
    - Na pasta `templates` (crie-a se não existir no mesmo diretório do script), adicione arquivos de texto com a extensão `.md`.
    - Dentro desses arquivos, use os seguintes placeholders onde deseja que as informações do arquivo Vue sejam inseridas:
        - `{{AQUI SERÁ INSERIDO O CONTEÚDO COMPLETO DO ARQUIVO .VUE}}`: Para o conteúdo completo do código Vue.
        - `{{NOME_DO_ARQUIVO_VUE}}`: Para o nome do arquivo Vue (ex: `MeuComponente.vue`).
3.  **Selecione um Template:** Escolha um dos seus templates `.md` no menu dropdown "Template de Análise".
4.  **Selecione o Diretório do Projeto Vue:**
    - Clique em "Procurar Diretório..." e navegue até a pasta raiz do seu projeto Vue.js.
    - Os arquivos `.vue` encontrados serão listados abaixo.
5.  **Navegue e Filtre os Arquivos Vue:**
    - Se houver muitos arquivos, use o botão "Carregar Mais Resultados" para ver mais.
    - Use o campo "Filtrar por nome:" e o botão "Aplicar Filtro" para refinar a lista de arquivos `.vue`.
6.  **Selecione um Arquivo Vue:** Clique no botão de rádio ao lado do arquivo `.vue` que deseja analisar.
7.  **Gere o Prompt:** Clique no botão "Gerar Prompt". O prompt combinado aparecerá na caixa de texto.
8.  **Copie ou Limpe:**
    - Use "Copiar para Área de Transferência" para copiar o prompt.
    - Use "Limpar Prompt" para limpar a caixa de texto.

## Contribuindo

Sugestões e contribuições são bem-vindas. Sinta-se à vontade para abrir uma issue ou um pull request.
