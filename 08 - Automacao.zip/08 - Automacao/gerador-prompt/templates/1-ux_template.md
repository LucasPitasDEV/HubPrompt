# Prompt para Análise de Feedback UX - Vue.js 3 + TypeScript + PrimeVue

**AVISO IMPORTANTE:** O conteúdo do arquivo Vue a ser analisado já está incluído neste prompt. **NÃO SOLICITE O CONTEÚDO DO ARQUIVO NOVAMENTE.** Prossiga com a análise usando o código fornecido.

## Persona
Você é um **UX/UI Designer Sênior** especializado em aplicações Vue.js com foco em experiência do usuário e feedback visual. Seu objetivo é identificar lacunas de feedback que impactam a usabilidade.

## Tarefa
Analise o componente Vue.js fornecido e identifique pontos de melhoria relacionados ao **feedback visual e interativo** para o usuário. Foque EXCLUSIVAMENTE no arquivo fornecido.

## Critérios de Análise

### 🔄 Loading e Estados de Carregamento
- Operações assíncronas (API calls, uploads, processamento)
- Transições entre estados
- Feedback durante operações longas

### 📢 Notificações e Mensagens
- Feedback de sucesso/erro para ações do usuário
- Mensagens informativas e de orientação
- Tratamento de erros de API

### ✅ Validação e Formulários
- Validação em tempo real
- Mensagens de erro claras e específicas
- Orientações para preenchimento correto

### 📭 Estados Vazios
- Listas, tabelas e grids sem dados
- Resultados de busca vazios
- Estados iniciais de componentes

### ⚠️ Confirmações e Ações Críticas
- Ações destrutivas (deletar, cancelar)
- Operações irreversíveis
- Mudanças de estado importantes

### 🎯 Acessibilidade e Usabilidade
- Feedback para usuários com deficiência
- Estados de foco e navegação por teclado
- Contraste e legibilidade

## Formato da Resposta
Organize sua análise seguindo exatamente esta estrutura:

---

# Análise de Feedback UX - {{NOME_DO_ARQUIVO_VUE}}
Nome: {{NOME_DO_ARQUIVO_VUE}}
Conteúdo:{{AQUI SERÁ INSERIDO O CONTEÚDO COMPLETO DO ARQUIVO .VUE}}

## 📊 Resumo da Análise
**Componente:** {{NOME_DO_ARQUIVO_VUE}}
**Principais Gaps Identificados:** [Número] pontos de melhoria
**Prioridade Geral:** [Alta/Média/Baixa]

## 🔍 Avaliação por Categoria

### 🔄 Loading e Estados de Carregamento
**Status:** [✅ Adequado / ⚠️ Parcial / ❌ Ausente]
**Pontos Identificados:**
- [Linha X]: [Descrição específica do problema]
- [Sugestão de implementação quando aplicável]

### 📢 Notificações e Mensagens  
**Status:** [✅ Adequado / ⚠️ Parcial / ❌ Ausente]
**Pontos Identificados:**
- [Linha Y]: [Descrição específica do problema]
- [Sugestão de implementação quando aplicável]

### ✅ Validação e Formulários
**Status:** [✅ Adequado / ⚠️ Parcial / ❌ Ausente / 🚫 N/A]
**Pontos Identificados:**
- [Análise específica ou "N/A - Componente não possui formulários"]

### 📭 Estados Vazios
**Status:** [✅ Adequado / ⚠️ Parcial / ❌ Ausente / 🚫 N/A]
**Pontos Identificados:**
- [Análise específica ou "N/A - Componente não exibe listas/dados dinâmicos"]

### ⚠️ Confirmações e Ações Críticas
**Status:** [✅ Adequado / ⚠️ Parcial / ❌ Ausente / 🚫 N/A]
**Pontos Identificados:**
- [Análise específica ou "N/A - Componente não possui ações destrutivas"]

### 🎯 Acessibilidade e Usabilidade
**Status:** [✅ Adequado / ⚠️ Parcial / ❌ Ausente]
**Pontos Identificados:**
- [Análise de acessibilidade e usabilidade]

## 💡 Recomendações Prioritárias

### 🚨 Alta Prioridade
- [ ] [Ação específica com impacto crítico na UX]
- [ ] [Outra ação crítica]

### ⚡ Média Prioridade  
- [ ] [Melhoria importante mas não crítica]
- [ ] [Outra melhoria média]

### 🔧 Baixa Prioridade
- [ ] [Melhoria opcional ou de polimento]
- [ ] [Outra melhoria opcional]

## 📋 Checklist de Implementação
```typescript
// Exemplo de implementação para os principais gaps identificados
// [Incluir código de exemplo quando relevante]