# Conversor de Postman Collection para Markdown

Este é um conversor que transforma uma coleção Postman (JSON) em uma documentação Markdown bem estruturada, organizando os endpoints em uma hierarquia de categorias e subcategorias para facilitar o mapeamento rápido da API.

## Funcionalidades

- Converte coleções Postman (formato JSON) em documentação Markdown estruturada
- Organiza a documentação em três níveis hierárquicos: índice principal, categorias e subcategorias
- Gera resumos com contagem de endpoints e descrições para cada subcategoria
- Cria tabelas de referência rápida com todos os endpoints
- Inclui detalhes completos de cada endpoint (método HTTP, URL, parâmetros, corpo, autenticação)
- Fornece estatísticas gerais sobre a API (total de subcategorias e endpoints)
- Mantém links de navegação entre os diferentes níveis da documentação

## Requisitos

- Python 3.6 ou superior

## Instalação

1. Clone ou baixe este repositório
2. Não há dependências externas além da biblioteca padrão do Python

## Como usar

```bash
python postman_to_markdown_final.py caminho/para/colecao_postman.json --output-dir pasta/de/saida
```

Por padrão, se o parâmetro `--output-dir` não for especificado, será criado um diretório com o nome do arquivo de entrada + "-docs-final".

### Exemplo com a coleção Digisac

```bash
python postman_to_markdown_final.py "Digisac-postman_collection.json" --output-dir "Documentacao-API-Digisac"
```

## Estrutura da documentação gerada

A documentação gerada é organizada em três níveis:

1. **Índice Principal** (`index.md`):
   - Visão geral de todas as categorias da API
   - Tabelas de resumo com contagem de endpoints por subcategoria
   - Descrições curtas de cada subcategoria
   - Estatísticas gerais (total de subcategorias e endpoints)

2. **Índices de Categorias** (`categoria/index.md`):
   - Lista de todas as subcategorias dentro da categoria
   - Tabela de resumo com contagem de endpoints por subcategoria
   - Links para voltar ao índice principal

3. **Arquivos de Subcategorias** (`categoria/subcategoria.md`):
   - Tabela com todos os endpoints da subcategoria
   - Detalhes completos de cada endpoint
   - Links para voltar ao índice da categoria

## Exemplo da estrutura de diretórios

```
documentacao-api/
├── index.md                  # Índice principal
├── categoria-1/
│   ├── index.md              # Índice da categoria 1
│   ├── subcategoria-1-1.md   # Endpoints da subcategoria 1.1
│   └── subcategoria-1-2.md   # Endpoints da subcategoria 1.2
└── categoria-2/
    ├── index.md              # Índice da categoria 2
    ├── subcategoria-2-1.md   # Endpoints da subcategoria 2.1
    └── subcategoria-2-2.md   # Endpoints da subcategoria 2.2
```

## Detalhes incluídos para cada endpoint

- Método HTTP (GET, POST, PUT, DELETE, etc.)
- URL completa e caminho do endpoint
- Parâmetros de consulta (query parameters)
- Corpo da requisição (request body)
- Autenticação
- Descrição (quando disponível)

## Vantagens desta abordagem

- **Organização hierárquica**: Facilita a navegação e compreensão da estrutura da API
- **Resumos informativos**: Fornece uma visão geral rápida de cada parte da API
- **Documentação completa**: Inclui todos os detalhes necessários para usar a API
- **Arquivos menores e focados**: Cada arquivo contém apenas informações relevantes para uma subcategoria específica
- **Navegação intuitiva**: Links para navegar facilmente entre os diferentes níveis da documentação

## Contribuições

Contribuições são bem-vindas! Sinta-se à vontade para abrir issues ou enviar pull requests para melhorar este conversor.
