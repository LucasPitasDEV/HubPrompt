#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Conversor de Postman Collection para Markdown (Versão Final)
Este script converte uma coleção Postman (JSON) em múltiplos arquivos Markdown,
criando um índice principal com resumo, arquivos para categorias e subcategorias.
"""

import json
import os
import sys
import argparse
import re
from typing import Dict, List, Any, Optional, Union

class PostmanToMarkdownFinal:
    def __init__(self, input_file: str, output_dir: str):
        """
        Inicializa o conversor.
        
        Args:
            input_file: Caminho para o arquivo JSON da coleção Postman
            output_dir: Diretório para salvar os arquivos Markdown
        """
        self.input_file = input_file
        self.output_dir = output_dir
        self.collection = None
        self.index_markdown = []
        
    def load_collection(self) -> None:
        """Carrega a coleção Postman do arquivo JSON."""
        try:
            with open(self.input_file, 'r', encoding='utf-8') as file:
                self.collection = json.load(file)
        except Exception as e:
            print(f"Erro ao carregar o arquivo JSON: {e}")
            sys.exit(1)
    
    def convert(self) -> None:
        """Converte a coleção Postman para múltiplos arquivos Markdown."""
        if not self.collection:
            self.load_collection()
        
        # Cria o diretório de saída se não existir
        os.makedirs(self.output_dir, exist_ok=True)
        
        # Adiciona o cabeçalho do documento de índice
        info = self.collection.get('info', {})
        title = info.get('name', 'API Documentation')
        description = info.get('description', '')
        
        self.index_markdown.append(f"# {title} - Índice da API")
        self.index_markdown.append("")
        
        if description:
            self.index_markdown.append(description)
            self.index_markdown.append("")
        
        self.index_markdown.append("## Categorias da API")
        self.index_markdown.append("")
        
        # Processa os itens da coleção para criar o índice e os arquivos por categoria
        self._process_categories(self.collection.get('item', []))
        
        # Salva o arquivo de índice
        index_path = os.path.join(self.output_dir, 'index.md')
        with open(index_path, 'w', encoding='utf-8') as file:
            file.write('\n'.join(self.index_markdown))
        print(f"Índice principal salvo em: {index_path}")
        
    def _process_categories(self, items: List[Dict]) -> None:
        """
        Processa as categorias principais da coleção.
        
        Args:
            items: Lista de itens da coleção
        """
        for item in items:
            if 'item' in item:  # É uma categoria
                category_name = item.get('name', 'Categoria')
                category_description = item.get('description', '')
                
                # Cria um nome de arquivo seguro para a categoria
                category_filename = self._create_safe_filename(category_name)
                
                # Cria um diretório para a categoria
                category_dir = os.path.join(self.output_dir, category_filename)
                os.makedirs(category_dir, exist_ok=True)
                
                # Adiciona a categoria ao índice principal
                self.index_markdown.append(f"### [{category_name}]({category_filename}/index.md)")
                self.index_markdown.append("")
                
                if category_description:
                    self.index_markdown.append(category_description)
                    self.index_markdown.append("")
                
                # Cria o conteúdo do arquivo de índice da categoria
                category_index = []
                category_index.append(f"# {category_name}")
                category_index.append("")
                
                if category_description:
                    category_index.append(category_description)
                    category_index.append("")
                
                category_index.append(f"[← Voltar ao Índice Principal](../index.md)")
                category_index.append("")
                
                category_index.append("## Subcategorias")
                category_index.append("")
                
                # Processa as subcategorias
                subcategories = item.get('item', [])
                
                # Adiciona um resumo das subcategorias ao índice principal
                self.index_markdown.append("**Resumo das Subcategorias:**")
                self.index_markdown.append("")
                self.index_markdown.append("| Subcategoria | Endpoints | Descrição |")
                self.index_markdown.append("| ------------ | --------- | --------- |")
                
                # Lista para armazenar as subcategorias para o índice da categoria
                subcategory_list = []
                
                # Processa cada subcategoria
                for subcategory in subcategories:
                    if 'item' in subcategory:  # É uma subcategoria com endpoints
                        subcategory_name = subcategory.get('name', 'Subcategoria')
                        subcategory_description = subcategory.get('description', '')
                        
                        # Cria um nome de arquivo seguro para a subcategoria
                        subcategory_filename = self._create_safe_filename(subcategory_name)
                        
                        # Adiciona a subcategoria à lista para o índice da categoria
                        subcategory_list.append(f"- [{subcategory_name}]({subcategory_filename}.md)")
                        
                        # Processa os endpoints desta subcategoria
                        endpoints = self._collect_endpoints(subcategory.get('item', []))
                        
                        # Adiciona a subcategoria ao resumo no índice principal
                        endpoint_count = len(endpoints)
                        short_description = subcategory_description.split('\n')[0] if subcategory_description else ""
                        if len(short_description) > 100:
                            short_description = short_description[:97] + "..."
                        
                        self.index_markdown.append(f"| [{subcategory_name}]({category_filename}/{subcategory_filename}.md) | {endpoint_count} | {short_description} |")
                        
                        # Cria o conteúdo do arquivo da subcategoria
                        subcategory_content = []
                        subcategory_content.append(f"# {subcategory_name}")
                        subcategory_content.append("")
                        
                        if subcategory_description:
                            subcategory_content.append(subcategory_description)
                            subcategory_content.append("")
                        
                        subcategory_content.append(f"[← Voltar à Categoria {category_name}]({category_filename}/index.md)")
                        subcategory_content.append("")
                        
                        # Adiciona a tabela de endpoints
                        if endpoints:
                            subcategory_content.append("## Endpoints")
                            subcategory_content.append("")
                            subcategory_content.append("| Método | Endpoint | Descrição |")
                            subcategory_content.append("| ------ | -------- | --------- |")
                            
                            for endpoint in endpoints:
                                method = endpoint.get('method', 'GET')
                                name = endpoint.get('name', 'Endpoint')
                                path = endpoint.get('path', '')
                                
                                # Formata o método
                                method_formatted = f"**{method}**"
                                
                                # Adiciona a linha da tabela
                                subcategory_content.append(f"| {method_formatted} | `{path}` | {name} |")
                            
                            subcategory_content.append("")
                            
                            # Adiciona os detalhes dos endpoints
                            for endpoint in endpoints:
                                self._add_endpoint_details(endpoint, subcategory_content)
                        
                        # Salva o arquivo da subcategoria
                        subcategory_path = os.path.join(category_dir, f"{subcategory_filename}.md")
                        with open(subcategory_path, 'w', encoding='utf-8') as file:
                            file.write('\n'.join(subcategory_content))
                        print(f"Subcategoria salva em: {subcategory_path}")
                
                # Adiciona a lista de subcategorias ao índice da categoria
                category_index.extend(subcategory_list)
                category_index.append("")
                
                # Adiciona uma tabela de resumo ao índice da categoria
                category_index.append("## Resumo de Endpoints por Subcategoria")
                category_index.append("")
                category_index.append("| Subcategoria | Endpoints | Descrição |")
                category_index.append("| ------------ | --------- | --------- |")
                
                for subcategory in subcategories:
                    if 'item' in subcategory:
                        subcategory_name = subcategory.get('name', 'Subcategoria')
                        subcategory_filename = self._create_safe_filename(subcategory_name)
                        subcategory_description = subcategory.get('description', '')
                        
                        # Processa os endpoints desta subcategoria
                        endpoints = self._collect_endpoints(subcategory.get('item', []))
                        endpoint_count = len(endpoints)
                        
                        # Adiciona a linha da tabela
                        short_description = subcategory_description.split('\n')[0] if subcategory_description else ""
                        if len(short_description) > 100:
                            short_description = short_description[:97] + "..."
                        
                        category_index.append(f"| [{subcategory_name}]({subcategory_filename}.md) | {endpoint_count} | {short_description} |")
                
                # Salva o arquivo de índice da categoria
                category_index_path = os.path.join(category_dir, 'index.md')
                with open(category_index_path, 'w', encoding='utf-8') as file:
                    file.write('\n'.join(category_index))
                print(f"Índice da categoria salvo em: {category_index_path}")
                
                self.index_markdown.append("")
                
                # Adiciona estatísticas gerais ao índice principal
                total_endpoints = sum(len(self._collect_endpoints(subcategory.get('item', []))) for subcategory in subcategories if 'item' in subcategory)
                total_subcategories = sum(1 for _ in subcategories if 'item' in _)
                
                self.index_markdown.append(f"**Total: {total_subcategories} subcategorias, {total_endpoints} endpoints**")
                self.index_markdown.append("")
    
    def _collect_endpoints(self, items: List[Dict]) -> List[Dict]:
        """
        Coleta todos os endpoints de uma subcategoria.
        
        Args:
            items: Lista de itens da subcategoria
            
        Returns:
            Lista de endpoints encontrados
        """
        endpoints = []
        
        for item in items:
            if 'request' in item:  # É um endpoint
                request = item.get('request', {})
                method = request.get('method', 'GET')
                
                url_data = request.get('url', {})
                url = url_data.get('raw', '') if isinstance(url_data, dict) else url_data
                
                # Extrai o caminho da URL
                path = ""
                if isinstance(url_data, dict) and 'path' in url_data:
                    path = '/' + '/'.join(url_data.get('path', []))
                else:
                    # Tenta extrair o caminho da URL completa
                    parts = url.split('/')
                    if len(parts) > 3:  # Tem pelo menos protocolo, host e algum caminho
                        path = '/' + '/'.join(parts[3:])
                    else:
                        path = url
                
                endpoints.append({
                    'name': item.get('name', 'Endpoint'),
                    'method': method,
                    'path': path,
                    'url': url,
                    'request': request,
                    'description': item.get('description', '')
                })
            elif 'item' in item:  # É um grupo aninhado
                # Recursivamente coleta endpoints do grupo aninhado
                nested_endpoints = self._collect_endpoints(item.get('item', []))
                endpoints.extend(nested_endpoints)
        
        return endpoints
    
    def _add_endpoint_details(self, endpoint: Dict, content_list: List[str]) -> None:
        """
        Adiciona detalhes de um endpoint ao conteúdo da subcategoria.
        
        Args:
            endpoint: Dicionário com informações do endpoint
            content_list: Lista de strings para adicionar o conteúdo
        """
        name = endpoint.get('name', 'Endpoint')
        method = endpoint.get('method', 'GET')
        url = endpoint.get('url', '')
        path = endpoint.get('path', '')
        request = endpoint.get('request', {})
        description = endpoint.get('description', '')
        
        # Adiciona o cabeçalho do endpoint
        content_list.append(f"### {method} {name}")
        content_list.append("")
        
        if description:
            content_list.append(description)
            content_list.append("")
        
        # URL completa
        content_list.append("**Endpoint:** `" + path + "`")
        content_list.append("")
        
        if url and url != path:
            content_list.append("**URL Completa:**")
            content_list.append(f"```\n{url}\n```")
            content_list.append("")
        
        # Parâmetros de consulta (query)
        url_data = request.get('url', {})
        if isinstance(url_data, dict) and 'query' in url_data and url_data['query']:
            content_list.append("**Parâmetros de Consulta:**")
            content_list.append("")
            content_list.append("| Parâmetro | Valor |")
            content_list.append("| --------- | ----- |")
            
            for param in url_data['query']:
                param_key = param.get('key', '')
                param_value = param.get('value', '')
                content_list.append(f"| `{param_key}` | `{param_value}` |")
            
            content_list.append("")
        
        # Corpo da requisição (body)
        body = request.get('body', {})
        if body:
            content_list.append("**Corpo da Requisição:**")
            content_list.append("")
            
            mode = body.get('mode', '')
            
            if mode == 'raw':
                raw_data = body.get('raw', '')
                language = 'json'
                
                # Tenta determinar a linguagem do corpo
                options = body.get('options', {})
                if isinstance(options, dict) and 'raw' in options:
                    language = options['raw'].get('language', 'json')
                
                content_list.append(f"```{language}")
                content_list.append(raw_data)
                content_list.append("```")
                content_list.append("")
            
            elif mode == 'formdata':
                formdata = body.get('formdata', [])
                if formdata:
                    content_list.append("| Parâmetro | Tipo | Valor |")
                    content_list.append("| --------- | ---- | ----- |")
                    
                    for param in formdata:
                        param_key = param.get('key', '')
                        param_type = param.get('type', 'text')
                        param_value = param.get('value', '')
                        content_list.append(f"| `{param_key}` | `{param_type}` | `{param_value}` |")
                    
                    content_list.append("")
        
        # Autenticação
        auth = request.get('auth', {})
        if auth:
            auth_type = auth.get('type', '')
            if auth_type:
                content_list.append(f"**Autenticação:** `{auth_type}`")
                content_list.append("")
        
        # Adiciona separador entre endpoints
        content_list.append("---")
        content_list.append("")
    
    def _create_safe_filename(self, text: str) -> str:
        """
        Cria um nome de arquivo seguro a partir de um texto.
        
        Args:
            text: Texto para converter em nome de arquivo
            
        Returns:
            Nome de arquivo seguro
        """
        # Remove caracteres especiais e substitui espaços por hífens
        filename = re.sub(r'[^\w\s-]', '', text.lower())
        filename = re.sub(r'[\s]+', '-', filename)
        return filename

def main():
    """Função principal."""
    parser = argparse.ArgumentParser(description='Converte uma coleção Postman (JSON) em múltiplos arquivos Markdown com resumo detalhado.')
    parser.add_argument('input_file', help='Caminho para o arquivo JSON da coleção Postman')
    parser.add_argument('--output-dir', '-o', default=None, help='Diretório para salvar os arquivos Markdown')
    
    args = parser.parse_args()
    
    # Se o diretório de saída não for especificado, cria um diretório com o nome do arquivo
    if not args.output_dir:
        output_dir = os.path.splitext(os.path.basename(args.input_file))[0] + '-docs-final'
        output_dir = os.path.join(os.path.dirname(args.input_file), output_dir)
    else:
        output_dir = args.output_dir
    
    converter = PostmanToMarkdownFinal(args.input_file, output_dir)
    converter.convert()
    print(f"Documentação final gerada com sucesso em: {output_dir}")

if __name__ == '__main__':
    main()
