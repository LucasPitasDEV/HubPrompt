# Framework de Criação de Projetos - Versão Adaptada

Este diretório contém prompts adaptados para serem utilizados com qualquer LLM (ChatGPT, Claude, Gemini, etc.), sem depender de uma IDE específica como o Windsurf.

## Estrutura Hierárquica

O framework segue uma estrutura hierárquica rigorosa, onde:

1. Cada nível é processado sequencialmente, um item por vez:
   - Primeiro todos os épicos são criados
   - Depois as features são criadas um épico por vez
   - Em seguida, as user stories são criadas uma feature por vez
   - Por fim, as tarefas são criadas uma user story por vez

2. A estrutura de pastas recomendada reflete essa hierarquia:
   ```
   resultados/
     - times/
     - epicos/
     - features/E001/
     - features/E002/
     - user-stories/E001/F001/
     - user-stories/E001/F002/
     - tarefas/E001/F001/US001/
     - tarefas/E001/F001/US002/
   ```

## Arquivos Adaptados

1. **1 - criador-epicos-adaptado.md**
   - Transforma documentação técnica em épicos de desenvolvimento
   - Deve ser executado primeiro no processo

2. **2 - criador-features-adaptado.md**
   - Desdobra um épico específico em features implementáveis
   - Utiliza o método RICE para priorização

3. **3 - criador-user-stories-adaptado.md**
   - Desdobra uma feature específica em user stories
   - Utiliza o formato "Como [persona], eu quero [ação] para que [benefício]"

4. **4 - criador-tarefas-adaptado.md**
   - Desdobra uma user story específica em tarefas técnicas
   - Atribui cada tarefa ao time responsável
   - Inclui "Definition of Ready" e "Definition of Done"

## Como Usar

1. **Definição de Times**:
   - Antes de iniciar o processo, defina quais times estão disponíveis para o projeto
   - O prompt de criação de tarefas perguntará explicitamente sobre os times disponíveis

2. **Uso Sequencial**:
   - Copie o conteúdo do prompt adaptado (entre "INÍCIO DO PROMPT" e "FIM DO PROMPT")
   - Cole em qualquer interface de LLM (ChatGPT, Claude, Gemini, etc.)
   - Forneça as informações solicitadas pelo LLM
   - Salve o resultado na estrutura de pastas recomendada

3. **Rastreabilidade**:
   - Mantenha a nomenclatura padronizada (E001, F001, US001, T001)
   - Garanta que cada item faça referência explícita ao item superior na hierarquia

## Técnicas Anti-Alucinação

Todos os prompts incluem técnicas específicas para evitar alucinações:

1. **Foco em um único item por vez**:
   - Cada prompt trabalha apenas com um item específico do nível superior
   - Exemplo: o criador de features trabalha com apenas um épico por vez

2. **Confirmação explícita**:
   - O LLM solicita confirmação do item específico a ser desdobrado
   - Exemplo: "Confirme qual épico específico será desdobrado em features"

3. **Validação de escopo**:
   - Verifica que todas as propostas estão dentro do escopo do item superior
   - Não permite extrapolar para outros itens do mesmo nível

4. **Estrita aderência à disponibilidade real**:
   - O criador de tarefas pergunta explicitamente quais times estão disponíveis
   - Atribui tarefas apenas aos times informados pelo usuário

## Observações Importantes

1. Cada prompt foi projetado para ser executado independentemente, sem depender de contexto de conversas anteriores.

2. As versões adaptadas mantêm todas as funcionalidades das versões originais, apenas removendo dependências de ferramentas específicas.

3. Recomenda-se salvar os resultados em arquivos separados para manter a organização e rastreabilidade do projeto.

4. Para projetos complexos, considere criar um documento de mapeamento para acompanhar a relação entre os diferentes níveis da hierarquia.
